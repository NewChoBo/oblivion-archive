﻿망각의 서재 · 사진에서 지워진 사람

sheets/에는 초기 서기관 삼면도, 환경 컨셉아트, 평면도와 텍스처 원판이 있습니다.
floating-citadel.webp와 fortress-blueprint.svg는 성채 원화와 높이를 표시한 설계도입니다.
sheets/work-review.html에서 현행 맵의 기물 배치 도면과 원화를 함께 볼 수 있습니다. 편집 원본은 design/work-layout.json, 게임과 같은 해석 결과는 sheets/citadel-placement-schedule.json에 있습니다.
chapter-map.glb는 성채 도착섬에서 봉인 보관실까지의 전체 공간이며 텍스처를 내장합니다.
library-route.svg는 지상층 동선입니다. citadel/에는 색과 노멀 맵, model-textures/에는 모델별 텍스처 원본이 있습니다.
skybox/에는 6면 큐브맵, 2:1 파노라마, 면 방향표가 있습니다.
ink-apparition.glb에는 Hover, Glide, Windup, Recover, Stagger가, outer-leviathan.glb에는 VoidSwim이 들어 있습니다. 콘셉트 시트는 sheets/에 있습니다.
archive-indirect.env와 rampart-indirect.env는 Babylon.js에서 쓰는 실내·성곽 반사광입니다.
archive-scribe.glb는 가면을 쓴 서기관입니다. 개별 GLB는 옆의 JPG 및 노멀 맵 PNG와 함께 두고 여세요.
서기관은 KayKit의 CC0 리그와 동작을 사용합니다. 마루는 Poly Haven의 CC0 자료입니다.
출처와 이용 조건 원문은 licenses/에 있습니다.
