import {TransformNode,MeshBuilder,PBRMaterial,StandardMaterial,Color3,Vector3} from '@babylonjs/core';
import {createCarvedSeal,createToolCrystal} from './arcane-art.js';

// Reversible project-authored silhouettes; the original Kenney GLBs stay intact.
export function createArcaneTool(scene,rig,id){
  const root=new TransformNode('서재의 마도구 시안',scene);root.parent=rig;
  const pbr=(name,color,metallic,roughness)=>{const m=new PBRMaterial(name,scene);m.albedoColor=Color3.FromHexString(color);m.metallic=metallic;m.roughness=roughness;m.maxSimultaneousLights=4;m.useGLTFLightFalloff=true;return m;};
  const bronze=pbr('봉인의 무딘 황동','#827048',.55,.68),shaft=pbr('완드의 어두운 나뭇결','#34453d',.1,.82),grip=pbr('마도구 가죽 감개','#292c29',0,.94);
  const glow=new StandardMaterial('여명의 빛 화살',scene);glow.disableLighting=true;glow.emissiveColor=new Color3(.48,.30,.10);
  const stringMat=new StandardMaterial('룬 활의 가는 빛줄',scene);stringMat.disableLighting=true;stringMat.emissiveColor=new Color3(.16,.12,.06);
  function cylinder(name,length,diameter,z,material){const m=MeshBuilder.CreateCylinder(name,{height:length,diameter,tessellation:10},scene);m.parent=root;m.rotation.x=Math.PI/2;m.position.z=z;m.material=material;return m;}
  let crystal,seal,arrow,drawString,tip,form;
  if(id==='blaster-a'){
    form='crystal-wand';cylinder('잔광 완드의 가느다란 몸체',.53,.034,-.015,shaft);cylinder('완드를 쥔 가죽 손잡이',.18,.048,-.16,grip);
    for(const z of [-.24,-.07,.14,.22])cylinder('완드의 황동 고리',.016,.052,z,bronze);
    crystal=createToolCrystal(scene,root);crystal.mesh.position.set(0,0,.255);crystal.mesh.rotation.x=Math.PI/2;crystal.mesh.scaling.setAll(.82);
    seal=createCarvedSeal(scene,'수정 완드에 새긴 봉인',bronze,{round:true,color:new Color3(.11,.40,.46)});seal.root.parent=root;seal.root.scaling.setAll(.12);seal.root.position.set(0,.03,-.045);
    tip=new Vector3(0,0,.35);
  }else{
    form='rune-bow';const path=[new Vector3(.10,.36,.015),new Vector3(-.035,.29,-.01),new Vector3(-.10,.13,-.025),new Vector3(-.115,0,-.035),new Vector3(-.10,-.13,-.025),new Vector3(-.035,-.29,-.01),new Vector3(.10,-.36,.015)];
    const limb=MeshBuilder.CreateTube('여명의 황동 룬 활대',{path,radius:.021,tessellation:8,cap:3},scene);limb.parent=root;limb.material=bronze;
    const handle=MeshBuilder.CreateCylinder('룬 활의 가죽 손잡이',{height:.15,diameter:.055,tessellation:10},scene);handle.parent=root;handle.position.set(-.115,0,-.035);handle.material=grip;
    drawString=MeshBuilder.CreateLines('활대 사이의 빛줄',{points:[path[0],new Vector3(.15,0,-.17),path.at(-1)],updatable:true},scene);drawString.parent=root;drawString.color=new Color3(.36,.26,.12);
    arrow=cylinder('활대 사이에 맺힌 빛 화살',.56,.009,.11,glow);arrow.position.x=.15;const head=MeshBuilder.CreateCylinder('빛 화살의 수정 촉',{height:.065,diameterTop:0,diameterBottom:.035,tessellation:4},scene);head.parent=root;head.rotation.x=Math.PI/2;head.position.set(.15,0,.42);head.material=glow;
    arrow.metadata={arrowHead:head};seal=createCarvedSeal(scene,'룬 활 손잡이의 봉인',bronze,{color:new Color3(.52,.31,.07)});seal.root.parent=root;seal.root.scaling.setAll(.12);seal.root.position.set(-.115,0,-.068);tip=new Vector3(.15,0,.455);
  }
  const meshes=root.getChildMeshes();for(const mesh of meshes){mesh.isPickable=false;mesh.metadata={...mesh.metadata,toolVisual:true};}
  let pull=0;
  return {root,meshes,tip,form,
    update({charge,reload,flash,ammo}){crystal?.update(charge);seal.setLevel(charge);pull=reload*.06;if(arrow){arrow.setEnabled(ammo>0&&flash<=0);arrow.metadata.arrowHead.setEnabled(ammo>0&&flash<=0);glow.emissiveColor=new Color3(.48,.30,.10).scale(.45+charge);MeshBuilder.CreateLines('bow string',{points:[new Vector3(.10,.36,.015),new Vector3(.15,0,-.17-pull),new Vector3(.10,-.36,.015)],instance:drawString},scene);}},
    grips(){return form==='crystal-wand'?{trigger:new Vector3(0,-.035,-.15),support:new Vector3(-.025,.015,.10),relaxLeft:true}:{trigger:new Vector3(.15,-.025,-.17-pull),support:new Vector3(-.115,-.025,-.035),relaxLeft:false};}
  };
}
