import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createSession} from '../src/session.js';
const definition=JSON.parse(fs.readFileSync(new URL('../public/data/library.json',import.meta.url)));
test('requires the active target and proximity, ignores duplicate actions, then records a complete return',()=>{
  const session=createSession(definition),start={x:0,z:-4.5};
  assert.equal(session.use('door',start),null);
  assert.equal(session.use('desk',{x:.4,z:.85}),null);
  assert.equal(session.use('fragment',{x:-4,z:6}),null);
  for(const step of definition.steps){const p={x:step.position[0],z:step.position[2]};assert.equal(session.use(step.target,p)?.id,step.id);assert.equal(session.use(step.target,p),null);}
  assert.equal(session.done,true);assert.equal(session.current,null);assert.equal(session.records.length,3);
  session.records.length=0;assert.equal(session.records.length,3);
  session.reset();assert.equal(session.completed,0);assert.equal(session.records.length,0);assert.equal(session.done,false);
});
