# 망각의 서재 · Babylon.js 플레이 데모

서재 한 곳에서 **이야기 조각 수집 → 중앙 책상에서 사진 복원 → 푸른 문턱에 기록 전달**을 플레이한다. 서로 다른 CC0 블래스터 두 개를 1인칭으로 장착하고 교체·발사·충전할 수 있다. Unity/Unreal 없이 Node.js, npm과 WebGL 2 브라우저로 실행한다.

## 실행

프로젝트 루트에서:

```powershell
cd web-demo
npm ci
npm run dev
```

`http://127.0.0.1:5173/`에서 **서재 들어가기**를 누른다. Node.js 22.12 이상이 필요하며 이 PC에서는 Node 24.18.0 / npm 11.16.0을 사용했다. 설치된 버전은 `package-lock.json`으로 고정했다. Unity 계정, Photon 키, 서버 계정은 필요하지 않다.

```powershell
npm test
npm run build
npm run preview
```

빌드 결과는 `dist/`, 로컬 빌드 검토 주소는 `http://127.0.0.1:4173/`다. 파일 더블클릭 대신 HTTP 서버로 연다. 두 서버는 Ctrl+C로 종료한다. 게임 실행 시 외부 CDN이나 에셋 사이트에서 파일을 받지 않는다. 배포·공개 호스팅은 하지 않았다.

## 조작과 진행

| 입력 | 동작 |
| --- | --- |
| WASD | 이동. 벽·책상·서가 충돌 적용 |
| 마우스 이동 | 버튼 없이 시점 회전. 입장/계속 클릭에서 Pointer Lock 요청 |
| E 또는 화면의 E 버튼 | 가까운 현재 목표 조사·수집·복원 |
| 좌클릭 / 누르고 있기 | 발사. 총기별 발사 간격이 다름 |
| 1 / 2 | 총기 교체 |
| V | 1·3인칭 전환. 위치·방향·기록·도구·탄약·충전 상태 유지 |
| R | 에너지 충전. 비어 있는 상태에서 발사해도 충전 시작 |
| Esc / Tab | 멈춤과 마우스 놓기. **계속하기** 클릭으로 재진입. **처음부터 다시**는 전체 초기화 |

입구 오른쪽 작은 탁자의 책을 E로 줍는다. 중앙 책상 앞에서 E로 사진을 복원하면 액자와 푸른 귀환문이 나타난다. 책상 오른쪽으로 돌아 문 가까이에서 E를 누르면 기록이 완료된다. 완료 화면에서 서재를 계속 둘러볼 수 있다. 진행은 현재 브라우저 세션 메모리에만 있다.

이 데모는 최신 Unity 데모의 작은 서재와 기록·복원 주제를 한 공간으로 압축한 웹 구현이다. 기존 전체 이야기, 전투, 증거 선택 퍼즐, 저장 및 멀티플레이를 모두 이식한 버전은 아니다. 총기는 장착·발사 연출을 확인하는 기능이며 적·피해 판정은 추가하지 않았다.

## 1·3인칭 플레이

기본은 1인칭이며 V를 누르면 후드·코트·가방·관절이 있는 서기관을 보는 어깨너머 시점으로 바뀐다. WASD는 두 시점 모두 카메라 방향을 기준으로 이동한다. 실제로 장착한 같은 GLB 마도구를 3인칭의 손에 옮겨 표시하므로 교체·발사·충전·탄약이 이어진다. 이동 시 보행과 멈췄을 때 자세 복귀가 있고, 벽·서가 앞에서는 카메라를 당기며 매우 가까워진 플레이어는 투명해져 시야를 확보한다. 캐릭터는 프로젝트에서 만든 도형과 관절이며 추가 외부 에셋은 없다.

입장/재개 버튼에서만 마우스 잠금을 요청한다. 성공하면 화면 끝에 걸리지 않고 연속 회전한다. 이 PC의 일반 Chrome 창에서 실제 잠금을 확인했고, Orca 내장 브라우저에서는 잠금이 거부되어 **버튼 없이 캔버스 안에서 이동하는 대체 시점**을 확인했다. 대체 방식에는 화면 끝 제한이 있다. Esc로 메뉴를 열어 커서를 옮긴 뒤 계속하기로 재개할 수 있다. 좌클릭은 발사 전용이고, 입장·메뉴 버튼 조작은 발사하지 않는다. Esc·잠금 해제·포커스 이탈에서 이동과 발사 유지를 해제하며 자동으로 재개하지 않는다.

HUD를 작은 제목·진행·탄약으로 줄였다. 전체 조작 안내는 입장과 메뉴에서만 보인다. 구현은 `src/player-input.js`, `src/player-view.js`, `src/camera-obstruction.js`이며 [시점 전환 검증 보고서](../Docs/Art/Oblivion-Player-View.md)에 브라우저별 결과와 같은 위치의 PNG가 있다.

## 심야의 봉인 서고 연출

기존의 밝은 주황 마루·빨간 러그·보라/황색 블래스터를 청회색 저조도 서재로 통일했다. 국소 호박색 램프가 중앙 기록대와 사진 옆 금속 인장을 비추며, 달빛의 실제 그림자와 거친 목재·무딘 황동이 공간의 깊이를 만든다. 귀환문에는 쐐기돌 아치와 음각 봉인을 추가했다. 사진을 복원하면 같은 도형의 인장이 **책상 → 바닥 → 아치 → 문** 순서로 약 3.3초 동안 깨어나고, 마지막에 문턱의 냉광이 켜진다.

단발 도구는 육각 수정, 연사 도구는 실제로 파낸 금속 각인판을 달았다. 두 도구의 낮은 채도·거친 마감과 가장자리 빛을 조정했으며, 충전 중 수정과 음각의 빛이 커졌다가 준비 상태로 돌아온다. 새 장식은 충돌·목표 판정을 추가하지 않는다. 진행 규칙·총기 수치·npm 흐름과 외부 에셋 원본 및 라이선스는 유지했다.

`src/arcane-art.js`에서 아치·공통 인장·수정을 구성하며, `src/main.js`가 조명과 복원 순서를 연결한다. 외부 서비스나 새 이미지 에셋은 사용하지 않았다. 전후 실제 배포 빌드 PNG와 현재 검증은 [작업 보고서](../Docs/Art/Oblivion-Dark-Fantasy-Archive.md) 및 `../Docs/Validation/2026-11-22/DarkStyle/`에 있다. 그 이전 밝은 장면의 `Web/` 캡처는 보존했다. 입구 전후는 1280×720, 같은 위치·회전·FOV이며, 사진 전후도 플레이 중 시점을 고정했다.

현재 연출 재검증은 새 preview 페이지에서 다음과 같이 실행한다. `-EvidenceDirectory`로 이전 캡처를 덮어쓰지 않을 위치를 지정한다.

```powershell
./tools/browser-acceptance.ps1 -PageId <page-id> -EvidenceDirectory ../Docs/Validation/2026-11-22/DarkStyle/after
```

## 실 에셋과 이용 조건

| 실제 사용 | 공식 출처 | 포함 위치·조건 |
| --- | --- | --- |
| 양쪽 서가 6개 | [Poly Haven Wooden Bookshelf Worn](https://polyhaven.com/a/wooden_bookshelf_worn), Ulan Cabanilla | `public/assets/polyhaven/bookshelf.gltf` + BIN + 원본 JPG. CC0 |
| 서재 마루 | [Poly Haven Old Wooden Floor 01](https://polyhaven.com/a/old_wooden_floor_01), Charlotte Baglioni / Dario Barresi | 1K 색상·노멀 JPG. CC0 |
| 잔광 블래스터 | [Kenney Blaster Kit 2.1](https://kenney.nl/assets/blaster-kit) | `public/assets/weapons/blaster-a.glb` + colormap. CC0 |
| 여명 블래스터 | 같은 팩 | `public/assets/weapons/blaster-j.glb`. 다른 기하·실루엣의 실제 모델. CC0 |
| 단발·연사·충전 소리 | [Kenney Sci-Fi Sounds 1.0](https://kenney.nl/assets/sci-fi-sounds) | `laserSmall_000.ogg`, `laserLarge_000.ogg`, `forceField_000.ogg`. CC0 |

상업 이용·수정·프로젝트에 포함한 재배포가 가능한 무료 에셋이다. [Poly Haven 조건](https://polyhaven.com/license), CC0 원문과 Kenney 팩의 원본 라이선스는 `public/assets/licenses/` 및 `dist/assets/licenses/`에 포함한다. Babylon의 Apache 2.0 원문도 동봉했다. 파일별 실제 크기와 SHA-256은 `public/assets/manifest.json`이다. 원본 팩 ZIP·선택한 원본 GLB/OGG·glTF/BIN은 상위 `Art/ThirdParty/`에 보존한다.

선반 glTF의 원본 기하는 유지하면서 색상 맵만 사용하는 파생 glTF를 만들었다. 금속·거칠기·변위·8K 맵은 가져오지 않았다. 원본 JPG·선택 GLB·OGG는 바이트를 변경하지 않았다. 책·책상·사진·벽·소품과 간단한 장갑은 프로젝트에서 구성한 도형이다. 상세 후보 비교는 `../Docs/Art/Oblivion-External-Environment.md`에 보존했다.

두 GLB를 직접 파싱하고 Babylon 로드 결과를 확인했으며, **원본 애니메이션 클립은 모두 0개**였다. 별도 magazine 메시가 있어, 이번 데모의 대기/이동 흔들림, 꺼내기, 교체, 반동, 탄창 이동·충전은 `src/weapons.js`에서 직접 구성했다. 원본에 걷기·발사·충전 클립이 들어 있다고 주장하지 않는다. 단발은 0.28초 간격·강한 반동·0.95초 충전, 연사는 0.12초 간격·작은 반동·1.35초 충전으로 구별한다. 사격 순간의 발사광·점광원·반동·효과음은 같은 발사 이벤트에서 시작하고 원래 자세로 감쇠한다.

## 코드와 후속 이식

- `public/data/library.json`: 방 치수, 서가 배치, 안정적인 목표 ID·위치·거리·기록. 엔진 공통 JSON.
- `src/session.js`: 순서·근접·중복 입력을 판정하는 엔진 독립 진행 규칙.
- `src/main.js`: Babylon 공간·충돌·시점·입력·한국어 UI 연결.
- `src/weapons.js`: 실제 GLB, 카메라 뷰모델, 입력·동작·발사광·소리 연결.
- `tools/prepare-assets.mjs`: 보관한 원본에서 실행 에셋과 라이선스를 재구성. `npm ci` 뒤 `npm run assets`로 실행.

GLB/glTF/BIN, JPG/PNG, OGG 및 상호작용 JSON을 보존해 후속 엔진에서도 사용할 수 있게 했다. 현재 Unity의 Asset/Scene 변경분은 상위 프로젝트에 보존하지만 새 웹 실행에는 사용하지 않는다.

참고한 [Ante Apocalypse](https://github.com/NewChoBo/ante_apocalypse/tree/cdbc52412a759615083d2bd9a23a3d14146a84ad)의 `PlayerPawn.ts`는 1.75m 눈높이 UniversalCamera, `PlayerController.ts`는 입력 차단 시 키 초기화, `AssetRegistry.ts`는 비동기 모델 컨테이너 재사용, `WeaponVisualController.ts`는 뷰모델 이동 연출을 사용한다. 이번 구현에는 입력 차단/포커스 이탈 시 키·발사 유지 해제, 한 번 로드한 서가의 복제, 카메라에 장착한 별도 총기 연출 패턴을 반영했다. 원본 Pistol/Rifle은 `Gun.glb` 하나를 함께 사용하고 크기를 달리하므로 이번에는 서로 다른 두 Kenney 모델을 선택했다. Ante 모델·텍스처·소리는 복사하지 않았다. 안내받은 로컬 `E:/work/vscode/project/ante_apocalypse`에는 `node_modules`만 있어 GitHub의 위 커밋을 읽기 전용으로 확인했다.

## 최초 웹 데모 검증 기록

2026-11-22, 이 PC의 Orca 브라우저에서 **일반 배포용 `dist`**를 실행했다.

- `npm ci` 성공, `npm test` 1/1 통과, `npm run build` 성공.
- 실제 키 누르기/떼기와 마우스 누르기/떼기로 일반 진입 → 두 GLB 교체 → 연속 사격 → R 충전 → 준비 자세 복귀를 확인. 최종 수집 결과는 사격 14회, 충전 2회, 교체 2회, 효과음 재생 Promise 성공 16회·실패 0회.
- WASD로 약 18.22m 실제 이동하고, 조각 수집·사진 복원·책상 충돌 및 우회·귀환 기록 3개 완료를 확인. 순간이동이나 진행 상태 강제 설정은 쓰지 않았다.
- Esc 일시정지 중 W를 유지해도 위치가 유지되며 전체 재시작에서 진행·소품·탄약 초기화를 확인.
- 일반 화면의 두 모델과 서가·마루를 직접 이미지 검토. 총구 방향을 수정하고 실제 발사 프레임에서 짧은 발사광을 확인.
- 최종 브라우저 콘솔 error 0개. 모델·색상 텍스처 요청 200, 오디오 Range 요청 206을 확인.

결과와 실제 PNG는 `../Docs/Validation/2026-11-22/Web/`에 있다. `01-arrival-blaster-a.png`, `03-blaster-j.png`, 총기별 `*-fire-0.png`~`*-fire-3.png`, `*-charge.png`, `*-ready.png`, `05-photo-restored.png`, `06-record-complete.png`를 확인한다. 발사 연속 프레임은 실제 캔버스 픽셀을 읽었으므로 HUD는 빠진다. 다른 플레이 캡처는 HUD를 포함한다.

Orca 환경에서 재현하려면 새 preview 페이지를 열고 준비 완료 후 `./tools/browser-acceptance.ps1 -PageId <page-id>`를 실행할 수 있다. 일반 플레이에는 Orca CLI가 필요 없다.

초기 ROOM_OF_DARK에는 Unity의 3인칭 데모가 있었고, 최초 웹 데모 작업 전에는 npm 웹 실행 경로·1인칭 총기·총기 애니메이션/사운드 연결이 없었다. 위 `Web/` 검증은 그때 만든 밝은 웹 장면의 기록이다. 이후 심야 서고 작업에서는 이 웹 장면을 변경 전 기준으로 보존하고 `DarkStyle/`에 같은 입구 구도의 전후를 새로 촬영했다.

실제 휴대폰 터치, 게임패드, 사람의 연속 수동 완주, 대표 기기별 FPS·발열, 장기 메모리는 아직 검증하지 않았다. 현재 조작은 데스크톱 키보드·마우스 기준이며, 포인터 잠금과 내장 브라우저의 대체 시점은 후속 1·3인칭 검증 보고서에서 구분한다. Orca의 배경/도킹 브라우저 FPS 값은 크게 변했으므로 성능 보장 수치로 사용하지 않는다. 빌드 전체는 약 10 MiB이며 추가 용량 최적화는 후속 범위다.
