import fs from 'node:fs';
import path from 'node:path';
const base=process.argv[2]||'../Art/ThirdParty/Kenney/BlasterSelection';
const result=[];
for(const name of ['blaster-a.glb','blaster-j.glb']){
  const bytes=fs.readFileSync(path.join(base,name));
  if(bytes.toString('ascii',0,4)!=='glTF')throw Error('Invalid GLB');
  const json=JSON.parse(bytes.toString('utf8',20,20+bytes.readUInt32LE(12)).trim());
  result.push({file:name,bytes:bytes.length,animations:json.animations?.map(a=>({name:a.name,channels:a.channels.length}))||[],images:json.images,meshes:json.meshes.map(m=>m.name),dimensions:json.accessors.filter(a=>a.type==='VEC3'&&a.min).map(a=>({min:a.min,max:a.max}))});
}
console.log(JSON.stringify(result,null,2));
