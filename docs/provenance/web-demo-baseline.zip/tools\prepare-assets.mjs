import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
const web=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'), repo=path.resolve(web,'..');
const output=path.join(web,'public/assets');fs.mkdirSync(output,{recursive:true});
const records=[];
function copy(source,destination) { const data=fs.readFileSync(path.join(repo,source));const target=path.join(output,destination);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,data);records.push({source,path:destination,bytes:data.length,sha256:crypto.createHash('sha256').update(data).digest('hex')}); }
const poly='Assets/_Oblivion/Art/PolyHaven/';
for(const name of ['wooden_bookshelf_worn_diff_1k.jpg','old_wooden_floor_01_diff_1k.jpg','old_wooden_floor_01_nor_gl_1k.jpg'])copy(poly+name,'polyhaven/'+name);
copy('Art/ThirdParty/PolyHaven/wooden_bookshelf_worn.bin','polyhaven/wooden_bookshelf_worn.bin');
const shelf=JSON.parse(fs.readFileSync(path.join(repo,'Art/ThirdParty/PolyHaven/wooden_bookshelf_worn_1k.gltf'),'utf8'));
// Keep the original engine-neutral geometry; only select the diffuse texture.
shelf.images=[{uri:'wooden_bookshelf_worn_diff_1k.jpg'}];shelf.textures=[{sampler:0,source:0}];
shelf.materials=[{name:'Worn wood',doubleSided:true,pbrMetallicRoughness:{baseColorTexture:{index:0},baseColorFactor:[.67,.54,.39,1],metallicFactor:0,roughnessFactor:.92}}];
fs.writeFileSync(path.join(output,'polyhaven/bookshelf.gltf'),JSON.stringify(shelf));
copy(poly+'CC0-1.0.txt','licenses/CC0-1.0.txt');copy(poly+'SOURCES.md','licenses/PolyHaven-SOURCES.md');
for(const name of ['blaster-a.glb','blaster-j.glb'])copy('Art/ThirdParty/Kenney/BlasterSelection/'+name,'weapons/'+name);
copy('Art/ThirdParty/Kenney/BlasterSelection/Textures/colormap.png','weapons/Textures/colormap.png');
copy('Art/ThirdParty/Kenney/BlasterSelection/License.txt','licenses/Kenney-Blaster-Kit.txt');
for(const name of ['laserSmall_000.ogg','laserLarge_000.ogg','forceField_000.ogg'])copy('Art/ThirdParty/Kenney/SoundSelection/'+name,'sounds/'+name);
copy('Art/ThirdParty/Kenney/SoundSelection/License.txt','licenses/Kenney-Sci-Fi-Sounds.txt');
copy('web-demo/node_modules/@babylonjs/core/license.md','licenses/Babylon-Core-Apache-2.0.md');
copy('web-demo/node_modules/@babylonjs/loaders/license.md','licenses/Babylon-Loaders-Apache-2.0.md');
fs.writeFileSync(path.join(output,'manifest.json'),JSON.stringify({generatedFrom:'local project sources; no runtime CDN',assets:records},null,2)+'\n');
console.log(`Prepared ${records.length} source files; ${records.reduce((sum,r)=>sum+r.bytes,0)} bytes.`);
