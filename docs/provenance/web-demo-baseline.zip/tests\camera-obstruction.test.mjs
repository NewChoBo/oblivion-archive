import test from 'node:test';
import assert from 'node:assert/strict';
import {clearCameraFraction} from '../src/camera-obstruction.js';
test('shoulder camera stops before a padded wall, including near-plane clearance',()=>{
  const wall={min:[-4,0,-2],max:[4,4,-1.8]},fraction=clearCameraFraction([0,1.6,0],[.42,0,-2.2],[wall],.2);
  assert.ok(fraction>0&&fraction<1);assert.ok(-2.2*fraction>-1.6);
});
test('parallel and diagonal sweeps retain shelf clearance without blocking an open arm',()=>{
  const shelf={min:[.4,0,-1.6],max:[1,3,-.5]};
  assert.ok(clearCameraFraction([0,1.6,0],[.6,0,-2],[shelf],.2)<1);
  assert.equal(clearCameraFraction([0,1.6,0],[-.6,0,-2],[shelf],.2),1);
  assert.equal(clearCameraFraction([0,1.6,0],[0,1,0],[shelf],.2),1);
});
test('an eye already inside the camera padding retracts rather than crossing geometry',()=>{
  assert.equal(clearCameraFraction([0,1.6,0],[0,0,-2],[{min:[-.1,1,-.1],max:[.1,2,.1]}]),0);
});
