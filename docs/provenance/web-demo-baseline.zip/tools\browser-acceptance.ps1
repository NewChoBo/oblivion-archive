param([Parameter(Mandatory=$true)][string]$PageId,[string]$EvidenceDirectory)
$ErrorActionPreference='Stop'
$repoRoot=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$evidence=if($EvidenceDirectory){[IO.Path]::GetFullPath($EvidenceDirectory)}else{Join-Path $repoRoot 'Docs\Validation\2026-11-22\Web'}
New-Item -ItemType Directory -Path $evidence -Force | Out-Null
function Invoke-Orca([string[]]$Arguments) {
    $response=(& orca @Arguments --json | Out-String) | ConvertFrom-Json
    if(-not $response.ok){throw ($response.error | ConvertTo-Json -Compress)}
    return $response.result
}
function Read-Browser([string]$Expression) {
    $result=Invoke-Orca @('eval','--page',$PageId,'--expression',$Expression)
    return ($result.result | ConvertFrom-Json)
}
function Key([string]$Name) { Invoke-Orca @('keypress','--page',$PageId,'--key',$Name) | Out-Null }
function Wait-State([string]$Predicate,[int]$Milliseconds=6000) {
    $js='new Promise(resolve=>{const deadline=performance.now()+__timeout__;function sample(){const s=window.__ROOM_DEMO__.snapshot();if((__predicate__)||performance.now()>deadline)resolve(s);else requestAnimationFrame(sample)}sample()})'
    return Read-Browser ($js.Replace('__predicate__',$Predicate).Replace('__timeout__',[string]$Milliseconds))
}
function Capture([string]$Name) {
    Invoke-Orca @('viewport','--page',$PageId,'--width','1280','--height','720') | Out-Null
    $result=Invoke-Orca @('screenshot','--page',$PageId)
    Copy-Item -LiteralPath $result.path -Destination (Join-Path $evidence ($Name+'.png'))
}
function Move-To([string]$Key,[int]$Axis,[double]$Target,[string]$Comparison,[int]$Timeout=10000) {
    Invoke-Orca @('exec','--page',$PageId,'--command',('keydown '+$Key)) | Out-Null
    try {
        $predicate='s.position[__axis__] __comparison__ __target__'
        $predicate=$predicate.Replace('__axis__',[string]$Axis).Replace('__comparison__',$Comparison).Replace('__target__',$Target.ToString([Globalization.CultureInfo]::InvariantCulture))
        $predicate='(('+ $predicate +')&&(window.dispatchEvent(new KeyboardEvent(`keyup`,{code:`Key'+$Key.ToUpperInvariant()+'`})),true))'
        return Wait-State $predicate $Timeout
    }
    finally { Invoke-Orca @('exec','--page',$PageId,'--command',('keyup '+$Key)) | Out-Null }
}
function Fire-Sequence([string]$Name) {
    $script='(()=>{window.__archiveFrames=[];const deadline=performance.now()+10000;let lastShot=window.__ROOM_DEMO__.snapshot().weapon.shots;function sample(){const s=window.__ROOM_DEMO__.snapshot();if(s.weapon.shots>lastShot){lastShot=s.weapon.shots;window.__archiveFrames.push({state:s,image:document.getElementById(`game`).toDataURL(`image/png`)});if(window.__archiveFrames.length===4)document.getElementById(`game`).dispatchEvent(new PointerEvent(`pointerup`,{pointerId:1}));}if(window.__archiveFrames.length<4&&performance.now()<deadline)requestAnimationFrame(sample)}requestAnimationFrame(sample);return true})()'
    Read-Browser $script | Out-Null
    Invoke-Orca @('mouse','move','--page',$PageId,'--x','300','--y','230') | Out-Null
    Invoke-Orca @('mouse','down','--page',$PageId,'--button','left') | Out-Null
    try { Wait-State 'window.__archiveFrames.length>=4' 8000 | Out-Null }
    finally { Invoke-Orca @('mouse','up','--page',$PageId,'--button','left') | Out-Null }
    $frames=Read-Browser 'window.__archiveFrames'
    if($frames.Count -lt 2){throw 'Missing firing frames.'}
    $index=0
    foreach($frame in $frames){$imageData=$frame.image.Split(',')[1];[IO.File]::WriteAllBytes((Join-Path $evidence ($Name+'-fire-'+$index+'.png')),[Convert]::FromBase64String($imageData));$index++}
    $frames | ForEach-Object { $_.state } | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $evidence ($Name+'-frames.json')) -Encoding UTF8
    $settled=Wait-State 's.weapon.state===`ready`&&s.weapon.recoil<.001' 7000
    Read-Browser '(()=>{window.__chargeFrames=[];const deadline=performance.now()+6000;let last=0;function sample(){const s=window.__ROOM_DEMO__.snapshot(),now=performance.now();if(s.weapon.state===`reloading`&&now-last>130){last=now;window.__chargeFrames.push({state:s,image:document.getElementById(`game`).toDataURL(`image/png`)});}if(window.__chargeFrames.length<4&&now<deadline)requestAnimationFrame(sample)}requestAnimationFrame(sample);return true})()' | Out-Null
    Key 'R'
    $settled=Wait-State 's.weapon.state===`ready`&&s.weapon.ammo===(s.weapon.id===`blaster-a`?6:14)' 7000
    if($settled.weapon.state -ne 'ready'){throw 'Weapon did not return to ready.'}
    $chargeFrames=Read-Browser 'window.__chargeFrames'
    if($chargeFrames.Count -lt 2){throw 'Missing actual recharge frames.'}
    $chargeIndex=0
    foreach($frame in $chargeFrames){[IO.File]::WriteAllBytes((Join-Path $evidence ($Name+'-charge-'+$chargeIndex+'.png')),[Convert]::FromBase64String($frame.image.Split(',')[1]));$chargeIndex++}
    $chargeFrames | ForEach-Object { $_.state } | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $evidence ($Name+'-charge-frames.json')) -Encoding UTF8
    $peakIndex=0
    for($i=1;$i -lt $chargeFrames.Count;$i++){if($chargeFrames[$i].state.weapon.arcane.charge -gt $chargeFrames[$peakIndex].state.weapon.arcane.charge){$peakIndex=$i}}
    Copy-Item -LiteralPath (Join-Path $evidence ($Name+'-charge-'+$peakIndex+'.png')) -Destination (Join-Path $evidence ($Name+'-charge.png'))
    Capture ($Name+'-ready')
    return $settled
}
$snapshot=Invoke-Orca @('snapshot','--page',$PageId,'--interactive')
$start=($snapshot.refs.psobject.Properties | Where-Object {$_.Value.name -eq '서재 들어가기'} | Select-Object -First 1).Name
if(-not $start){throw 'Open a fresh general entry point before acceptance.'}
Invoke-Orca @('click','--page',$PageId,'--element',('@'+$start)) | Out-Null
$arrival=Wait-State 's.weapon.state===`ready`' 5000
Capture '01-arrival-blaster-a'
$arrival=Read-Browser 'window.__ROOM_DEMO__.snapshot()'
$pistol=Fire-Sequence '02-blaster-a'
Key '2'
$rifleReady=Wait-State 's.weapon.id===`blaster-j`&&s.weapon.state===`ready`' 5000
Capture '03-blaster-j'
$rifle=Fire-Sequence '04-blaster-j'
Key '1'
Wait-State 's.weapon.state===`ready`' 5000 | Out-Null
$fragmentApproach=Move-To 'd' 0 2.15 '>='
Key 'E'
$collected=Read-Browser 'window.__ROOM_DEMO__.snapshot()'
if($collected.phase -ne 1){throw 'Fragment collection failed.'}
$deskApproach=Move-To 'w' 2 .3 '>='
Move-To 'a' 0 1 '<=' | Out-Null
Capture '05a-desk-before-restoration'
Read-Browser '(()=>{window.__restorationFrames=[];const times=[0,.45,.9,1.5,2.1,2.8,3.4],deadline=performance.now()+10000;let started=null;function sample(){const s=window.__ROOM_DEMO__.snapshot(),now=performance.now();if(s.phase>=2){if(started===null)started=now;const elapsed=(now-started)/1000;if(elapsed>=times[window.__restorationFrames.length])window.__restorationFrames.push({elapsed,state:s,image:document.getElementById(`game`).toDataURL(`image/png`)});}if(window.__restorationFrames.length<times.length&&now<deadline)requestAnimationFrame(sample)}requestAnimationFrame(sample);return true})()' | Out-Null
Key 'E'
$restored=Read-Browser 'window.__ROOM_DEMO__.snapshot()'
if($restored.phase -ne 2){throw 'Photo restoration failed.'}
if($restored.lighting){$restorationSettled=Wait-State 's.lighting.restorationProgress>=1&&window.__restorationFrames.length>=7' 6500}
Capture '05-photo-restored'
$restorationFrames=Read-Browser 'window.__restorationFrames'
$restorationIndex=0
foreach($frame in $restorationFrames){[IO.File]::WriteAllBytes((Join-Path $evidence ('05-restoration-'+$restorationIndex+'.png')),[Convert]::FromBase64String($frame.image.Split(',')[1]));$restorationIndex++}
$restorationFrames|ForEach-Object {[pscustomobject]@{elapsed=$_.elapsed;state=$_.state}}|ConvertTo-Json -Depth 15|Set-Content -LiteralPath (Join-Path $evidence 'restoration-timeline.json') -Encoding UTF8
$collision=Move-To 'w' 2 2.3 '>=' 2500
if($collision.position[2] -gt 1.1){throw 'Desk collision did not block walking.'}
Move-To 'd' 0 2.2 '>=' | Out-Null
Move-To 'w' 2 4.8 '>=' | Out-Null
Move-To 'a' 0 0 '<=' | Out-Null
Move-To 'w' 2 5.1 '>=' | Out-Null
Key 'E'
$complete=Read-Browser 'window.__ROOM_DEMO__.snapshot()'
if($complete.phase -ne 3 -or $complete.records.Count -ne 3){throw 'Library return failed.'}
Capture '06-record-complete'
$result=[ordered]@{url='http://127.0.0.1:4173/';method='Real browser keydown/keyup, mouse down/up and rendered-frame readback; normal release events bound automated holds; no teleport or quest-state setters';arrival=$arrival;pistol=$pistol;rifle=$rifle;collected=$collected;restored=$restored;restorationSettled=$restorationSettled;deskCollision=$collision;complete=$complete}
$result | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $evidence 'browser-acceptance.json') -Encoding UTF8
Write-Output ('PASS: '+(Join-Path $evidence 'browser-acceptance.json'))
