﻿param([Parameter(Mandatory=$true)][string]$PageId,[string]$EvidenceDirectory='Docs/Validation/2026-11-22/PlayerView/Orca')
$ErrorActionPreference='Stop'
$evidence=[IO.Path]::GetFullPath($EvidenceDirectory)
New-Item -ItemType Directory -Path $evidence -Force | Out-Null
function Cmd([string[]]$Arguments){$r=(& orca @Arguments --json|Out-String)|ConvertFrom-Json;if(-not $r.ok){throw ($r.error|ConvertTo-Json -Compress)};return $r.result}
function Read([string]$Expression='window.__ROOM_DEMO__.snapshot()'){$r=Cmd @('eval','--page',$PageId,'--expression',$Expression);return ($r.result|ConvertFrom-Json)}
function Wait([string]$Predicate,[int]$Timeout=9000){return Read ('new Promise(resolve=>{const end=performance.now()+__TIME__;function sample(){const s=window.__ROOM_DEMO__.snapshot();if((__TEST__)||performance.now()>end)resolve(s);else requestAnimationFrame(sample)}sample()})'.Replace('__TIME__',"$Timeout").Replace('__TEST__',$Predicate))}
function Key([string]$Value){Cmd @('keypress','--page',$PageId,'--key',$Value)|Out-Null}
function Capture([string]$Name){Cmd @('viewport','--page',$PageId,'--width','1280','--height','720')|Out-Null;$c=Cmd @('screenshot','--page',$PageId);Copy-Item -LiteralPath $c.path -Destination (Join-Path $evidence ($Name+'.png'))}
function Mouse([int]$X,[int]$Y){Cmd @('mouse','move','--page',$PageId,'--x',"$X",'--y',"$Y")|Out-Null}
function Button([string]$Name){$s=Cmd @('snapshot','--page',$PageId,'--interactive');$ref=($s.refs.psobject.Properties|Where-Object{$_.Value.name -eq $Name}|Select-Object -First 1).Name;if(-not $ref){throw "Missing button: $Name"};Cmd @('click','--page',$PageId,'--element',('@'+$ref))|Out-Null}
function Sensitivity([int]$Steps){Mouse 100 100;$box=Read '(()=>{const r=document.getElementById(`sensitivity`).getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}})()';$value=.25+$Steps*.05;$x=[int]($box.x+8+($box.width-16)*($value-.25)/2.75);$y=[int]($box.y+$box.height/2);Mouse $x $y;Cmd @('mouse','down','--page',$PageId,'--button','left')|Out-Null;Cmd @('mouse','up','--page',$PageId,'--button','left')|Out-Null;$actual=(Read).preferences.sensitivity;if([Math]::Abs($actual-$value) -gt .01){throw "Slider click produced $actual instead of $value"}}
function MovePlayer([string]$Key,[int]$Axis,[double]$Target,[string]$Op){Cmd @('exec','--page',$PageId,'--command',('keydown '+$Key))|Out-Null;try{return Wait ('s.position['+$Axis+']'+$Op+$Target.ToString([Globalization.CultureInfo]::InvariantCulture)+'&&(window.dispatchEvent(new KeyboardEvent(`keyup`,{code:`Key'+$Key.ToUpperInvariant()+'`})),true)')}finally{Cmd @('exec','--page',$PageId,'--command',('keyup '+$Key))|Out-Null}}
function Equal-Continuity($Before,$After){return (($Before.position|ConvertTo-Json -Compress) -eq ($After.position|ConvertTo-Json -Compress) -and $Before.yaw -eq $After.yaw -and $Before.pitch -eq $After.pitch -and $Before.phase -eq $After.phase -and $Before.weapon.id -eq $After.weapon.id -and $Before.weapon.ammo -eq $After.weapon.ammo)}
$result=[ordered]@{browser='Orca embedded browser';method='Native Orca mouse move without button, keyboard and UI clicks; read-only diagnostics; no teleport or progression setter'}
Wait 's.ready'|Out-Null
$result.originalPreferences=(Read).preferences
Button '설정'
if($result.originalPreferences.pointerLock){Button '입장할 때 마우스 잠금 요청'}
Sensitivity 5
Button '메뉴로 돌아가기'
Button '서재 들어가기'
$result.entry=Wait 's.input.mode!==`requesting`&&s.weapon.state===`ready`'
if($result.entry.input.mode -ne 'free-look'){throw 'This receipt is specifically for the no-lock fallback; report actual lock mode separately.'}
if($result.entry.weapon.shots -ne 0){throw 'Entry click fired.'}
Mouse 200 250
$result.firstLookBefore=Read
Capture '01-before-no-button-look'
Mouse 380 250
$result.firstLookAfter=Wait 'Math.abs(s.camera.rotation[1]-s.yaw)<.0001'
if([Math]::Abs($result.firstLookAfter.yaw-$result.firstLookBefore.yaw) -lt .2 -or $result.firstLookAfter.weapon.shots -ne 0){throw 'Fallback mouse look did not rotate safely.'}
Capture '02-after-no-button-look'
Mouse 200 250
Wait 'Math.abs(s.yaw)<.01'|Out-Null
MovePlayer 'w' 2 -2.2 '>='|Out-Null
$result.beforeToggle=Read
Capture '03-same-position-first'
Key 'V'
$result.afterToggle=Wait 's.viewMode===`third`'
if(-not (Equal-Continuity $result.beforeToggle $result.afterToggle)){throw 'First/third toggle lost state.'}
Capture '04-same-position-third'
Mouse 200 250
$result.thirdLookBefore=Read
Mouse 380 250
$result.thirdLookAfter=Wait 'Math.abs(s.camera.rotation[1]-s.yaw)<.0001'
if([Math]::Abs($result.thirdLookAfter.yaw-$result.thirdLookBefore.yaw) -lt .2 -or $result.thirdLookAfter.weapon.shots -ne 0){throw 'Third-person fallback look did not rotate safely.'}
Capture '05-third-no-button-look'
Mouse 200 250
Wait 'Math.abs(s.yaw)<.01'|Out-Null
$result.roundTripBefore=Read
Key 'V'
$result.roundTripAfter=Wait 's.viewMode===`first`'
if(-not (Equal-Continuity $result.roundTripBefore $result.roundTripAfter)){throw 'Round trip lost state.'}
Key 'V'
MovePlayer 's' 2 -5.38 '<='|Out-Null
$result.wall=Read
if(-not $result.wall.player.obstructed -or $result.wall.player.cameraDistance -gt .8){throw 'Wall camera did not retract.'}
Capture '06-wall-camera'
MovePlayer 'w' 2 -2.7 '>='|Out-Null
MovePlayer 'd' 0 3.23 '>='|Out-Null
$result.shelf=Read
if(-not $result.shelf.player.obstructed -or $result.shelf.player.cameraDistance -gt 1){throw 'Shelf camera did not retract.'}
Capture '07-shelf-camera'
Key 'Escape'
$result.paused=Read
Cmd @('exec','--page',$PageId,'--command','keydown w')|Out-Null
try{$result.pausedHeld=Read 'new Promise(resolve=>{const end=performance.now()+500;function sample(){if(performance.now()>=end)resolve(window.__ROOM_DEMO__.snapshot());else requestAnimationFrame(sample)}sample()})'}finally{Cmd @('exec','--page',$PageId,'--command','keyup w')|Out-Null}
if(-not (Equal-Continuity $result.paused $result.pausedHeld)){throw 'Paused movement leaked.'}
Button '계속하기'
$result.resumed=Wait 's.input.mode!==`requesting`'
if(-not (Equal-Continuity $result.pausedHeld $result.resumed) -or $result.resumed.weapon.held){throw 'Explicit resume lost state or fired.'}
# UI clicks must never become a canvas fire input.
Button '메뉴 · Esc'
$result.ui=Read
if($result.ui.weapon.shots -ne 0){throw 'UI navigation fired.'}
Button '계속하기'
$result.sensitivityHalf=[Math]::Abs($result.firstLookAfter.yaw-$result.firstLookBefore.yaw)
Key 'Escape'
Button '설정'
Sensitivity 25
Button '메뉴로 돌아가기'
Button '계속하기'
Wait 's.input.mode===`free-look`'|Out-Null
Mouse 200 250
$result.highSensitivityBefore=Read
Mouse 380 250
$result.highSensitivityAfter=Read
$result.sensitivityOneHalf=[Math]::Abs($result.highSensitivityAfter.yaw-$result.highSensitivityBefore.yaw)
if([Math]::Abs($result.sensitivityOneHalf/$result.sensitivityHalf-3) -gt .15){throw 'Fallback sensitivity ratio failed.'}
Key 'Escape'
Button '설정'
Sensitivity 15
if($result.originalPreferences.pointerLock){Button '입장할 때 마우스 잠금 요청'}
Capture '08-settings'
Button '메뉴로 돌아가기'
$result.pass=$true
$result|ConvertTo-Json -Depth 16|Set-Content (Join-Path $evidence 'acceptance.json') -Encoding UTF8
Cmd @('console','--page',$PageId,'--limit','200')|ConvertTo-Json -Depth 8|Set-Content (Join-Path $evidence 'console.json') -Encoding UTF8
Write-Output ('PASS '+(Join-Path $evidence 'acceptance.json'))
