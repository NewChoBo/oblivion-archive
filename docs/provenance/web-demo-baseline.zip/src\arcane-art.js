import {CSG,MeshBuilder,Mesh,VertexData,TransformNode,Vector3,Color3,PBRMaterial} from '@babylonjs/core';

// One geometric seal is repeated in the desk stamp, the door and both tools.
// Its channels are subtracted from solid geometry, rather than drawn as text.
const strokes=[
  [[0,.28],[.20,0]],[[.20,0],[0,-.28]],[[0,-.28],[-.20,0]],[[-.20,0],[0,.28]],
  [[0,.28],[0,.50]],[[0,-.28],[0,-.50]],
  [[-.45,.18],[-.25,0]],[[-.25,0],[-.45,-.18]],
  [[.45,.18],[.25,0]],[[.25,0],[.45,-.18]]
];
const clamp=x=>Math.max(0,Math.min(1,x));
const smooth=x=>{x=clamp(x);return x*x*(3-2*x);};
function pbr(scene,name,color,metallic=0,roughness=.88){const m=new PBRMaterial(name,scene);m.albedoColor=Color3.FromHexString(color);m.metallic=metallic;m.roughness=roughness;m.maxSimultaneousLights=4;m.useGLTFLightFalloff=true;return m;}

export function createCarvedSeal(scene,name,surface,{round=false,color=new Color3(.12,.34,.38)}={}){
  const root=new TransformNode(name,scene);
  const base=round?MeshBuilder.CreateCylinder('seal blank',{diameter:.48,height:.10,tessellation:24},scene):MeshBuilder.CreateBox('seal blank',{width:.58,height:.68,depth:.10},scene);
  if(round)base.rotation.x=Math.PI/2;
  let solid=CSG.FromMesh(base);base.dispose();
  const glow=pbr(scene,`${name} groove`,'#081014',0,.76);
  for(const [i,[a,b]] of strokes.entries()){
    const x=(a[0]+b[0])*.21,y=(a[1]+b[1])*.21,length=Math.hypot(b[0]-a[0],b[1]-a[1])*.42,angle=Math.atan2(b[1]-a[1],b[0]-a[0]);
    const cutter=MeshBuilder.CreateBox('engraving cutter',{width:length+.012,height:.023,depth:.09},scene);cutter.position.set(x,y,-.025);cutter.rotation.z=angle;
    solid.subtractInPlace(CSG.FromMesh(cutter));cutter.dispose();
    const inset=MeshBuilder.CreateBox(`${name} inset ${i}`,{width:length,height:.010,depth:.006},scene);inset.parent=root;inset.position.set(x,y,-.006);inset.rotation.z=angle;inset.material=glow;inset.receiveShadows=true;
  }
  const carved=solid.toMesh(`${name} carved solid`,surface,scene);carved.parent=root;carved.receiveShadows=true;
  let level=0;
  const api={root,meshes:root.getChildMeshes(),setLevel(value){level=clamp(value);glow.emissiveColor=color.scale(.012+level*.65);},get level(){return level;}};
  api.setLevel(0);return api;
}

function archBlock(scene,index,inner,outer,start,end,material){
  const positions=[],indices=[];
  for(const z of [6.60,7.12])for(const [r,angle] of [[inner,start],[outer,start],[outer,end],[inner,end]])positions.push(Math.cos(angle)*r,1.8+Math.sin(angle)*r,z);
  for(const face of [[0,3,2,1],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]])indices.push(face[0],face[1],face[2],face[0],face[2],face[3]);
  const mesh=new Mesh(`흑석 아치 쐐기 ${index}`,scene),data=new VertexData();data.positions=positions;data.indices=indices;data.normals=[];VertexData.ComputeNormals(positions,indices,data.normals);data.applyToMesh(mesh);mesh.convertToFlatShadedMesh();mesh.material=material;mesh.receiveShadows=true;return mesh;
}

export function createArchiveMagic(scene){
  const stone=pbr(scene,'젖은 청회색 흑석','#536069',0,.94),metal=pbr(scene,'인장에 남은 무딘 황동','#736146',.68,.64);
  for(let i=0;i<11;i++)archBlock(scene,i,1.12,1.56,i*Math.PI/11+.012,(i+1)*Math.PI/11-.012,stone);
  for(const side of [-1,1]){
    const pillar=MeshBuilder.CreateBox('봉인문 석주',{width:.44,height:1.8,depth:.58},scene);pillar.position.set(side*1.34,.9,6.86);pillar.material=stone;pillar.receiveShadows=true;
    const foot=MeshBuilder.CreateBox('석주 밑돌',{width:.60,height:.18,depth:.74},scene);foot.position.set(side*1.34,.09,6.86);foot.material=stone;foot.receiveShadows=true;
  }
  const desk=createCarvedSeal(scene,'기록대의 금속 인장',metal,{round:true,color:new Color3(.60,.33,.09)});desk.root.position.set(.12,1.32,1.50);desk.root.rotation.x=Math.PI/2-.36;desk.root.scaling.setAll(.60);
  const sequence=[{seal:desk,delay:0}];
  for(const [i,z] of [3.4,4.5,5.6].entries()){
    const seal=createCarvedSeal(scene,`바닥에 박힌 인장 ${i}`,metal,{round:true});seal.root.position.set(0,.008,z);seal.root.rotation.x=Math.PI/2;seal.root.scaling.setAll(.55);sequence.push({seal,delay:.45+i*.35});
  }
  for(const [i,angle] of [.15*Math.PI,.85*Math.PI,.325*Math.PI,.675*Math.PI,.5*Math.PI].entries()){
    const seal=createCarvedSeal(scene,`아치의 음각 봉인 ${i}`,stone);seal.root.position.set(Math.cos(angle)*1.34,1.8+Math.sin(angle)*1.34,6.56);seal.root.rotation.z=angle-Math.PI/2;seal.root.scaling.setAll(.69);sequence.push({seal,delay:1.45+Math.floor(i/2)*.36});
  }
  const door=createCarvedSeal(scene,'문 중심의 봉인',metal,{round:true});door.root.position.set(0,1.6,7.43);door.root.scaling.setAll(2.0);sequence.push({seal:door,delay:2.65});
  return {update(elapsed){for(const entry of sequence)entry.seal.setLevel(elapsed<0?0:smooth((elapsed-entry.delay)/.55));return elapsed<0?0:smooth((elapsed-2.65)/.6);},snapshot(){return sequence.map(entry=>({name:entry.seal.root.name,level:entry.seal.level,delay:entry.delay}));}};
}

export function createToolCrystal(scene,parent){
  const mesh=new Mesh('집속기의 육각 수정',scene),positions=[],indices=[];
  const points=[[0,.115,0],[0,-.075,0],...Array.from({length:6},(_,i)=>[Math.cos(i*Math.PI/3)*.052,0,Math.sin(i*Math.PI/3)*.052])];
  positions.push(...points.flat());
  for(let i=0;i<6;i++){const a=2+i,b=2+(i+1)%6;indices.push(0,b,a,1,a,b);}
  const data=new VertexData();data.positions=positions;data.indices=indices;data.normals=[];VertexData.ComputeNormals(positions,indices,data.normals);data.applyToMesh(mesh);mesh.convertToFlatShadedMesh();
  const material=pbr(scene,'빛을 품은 스모키 수정','#16333a',.08,.28);mesh.material=material;mesh.parent=parent;mesh.position.set(0,.13,-.06);mesh.renderingGroupId=2;mesh.isPickable=false;
  return {mesh,update(level){material.emissiveColor=new Color3(.055,.32,.37).scale(.14+level*.85);}};
}
