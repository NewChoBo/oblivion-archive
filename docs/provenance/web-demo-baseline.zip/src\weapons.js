import {SceneLoader,TransformNode,Vector3,Color3,PointLight,MeshBuilder,StandardMaterial,PBRMaterial,ImageProcessingConfiguration,ColorCurves,Matrix} from '@babylonjs/core';
import {createCarvedSeal,createToolCrystal} from './arcane-art.js';
import {createWeaponAudio} from './weapon-audio.js';
import {createArcaneTool} from './arcane-tools.js';
const ARCANE_TOOLS=true;

const definitions=[
  {id:'blaster-a',title:ARCANE_TOOLS?'잔광 · 봉인의 수정 완드':'잔광 · 단발 블래스터',length:.52,depth:.72,capacity:6,interval:.28,kick:.075,recover:19,equip:.38,reload:.95,color:'#80d9e1',sound:'laserSmall_000.ogg'},
  {id:'blaster-j',title:ARCANE_TOOLS?'여명 · 빛살 룬 활':'여명 · 연사 블래스터',length:.78,depth:.82,capacity:14,interval:.12,kick:.043,recover:24,equip:.52,reload:1.35,color:'#ffc17b',sound:'laserLarge_000.ogg'}
];
export async function createWeapons(scene,camera,{$,toast,thirdPersonAnchor,getKeyLabel=()=> 'R',onShot=()=>{},onReset=()=>{}}){
  const weapons=[],stats={shots:0,switches:0,reloads:0,audioPlays:0,audioErrors:0};
  let selected=0,equip=.45,reloadTime=0,cooldown=0,kick=0,flashTime=0,clock=0,held=false,muted=false,thirdPerson=false,emptyLatch=false;
  const sound=createWeaponAudio({onPlay:()=>stats.audioPlays++,onError:()=>stats.audioErrors++});
  const pendingShots=[];
  for(const [i,definition] of definitions.entries()){
    const result=await SceneLoader.ImportMeshAsync('','./assets/weapons/',`${definition.id}.glb`,scene);
    const rig=new TransformNode(`${definition.id} viewmodel`,scene);
    const normalized=new TransformNode('model normalization',scene);normalized.parent=rig;
    // Kenney's GLB muzzle points toward the viewer after the RH-to-LH import.
    // Turn the geometry so the muzzle points along the camera's +Z direction.
    normalized.rotation.y=Math.PI;
    for(const mesh of result.meshes)if(!mesh.parent)mesh.parent=normalized;
    let bounds=normalized.getHierarchyBoundingVectors(true);const sourceSize=bounds.max.subtract(bounds.min);
    const scale=definition.length/sourceSize.z;normalized.scaling.setAll(scale);normalized.computeWorldMatrix(true);for(const mesh of result.meshes)mesh.computeWorldMatrix(true);
    bounds=normalized.getHierarchyBoundingVectors(true);normalized.position.copyFrom(bounds.min.add(bounds.max).scale(-.5));
    rig.parent=camera;
    const arcane=ARCANE_TOOLS?createArcaneTool(scene,rig,definition.id):null;if(arcane)normalized.setEnabled(false);
    // Read the actual front band after glTF handedness, turn and normalization.
    // Keep flash and opaque viewmodel in the same depth buffer/render group.
    rig.computeWorldMatrix(true);const inverseRig=Matrix.Invert(rig.getWorldMatrix()),front=[];
    for(const mesh of result.meshes.filter(m=>!m.name.toLowerCase().includes('magazine'))){const vertices=mesh.getVerticesData('position');if(!vertices)continue;mesh.computeWorldMatrix(true);const matrix=mesh.getWorldMatrix().multiply(inverseRig);for(let j=0;j<vertices.length;j+=3)front.push(Vector3.TransformCoordinates(Vector3.FromArray(vertices,j),matrix));}
    const frontZ=Math.max(...front.map(v=>v.z)),band=front.filter(v=>v.z>frontZ-.012),tip=arcane?.tip||new Vector3((Math.min(...band.map(v=>v.x))+Math.max(...band.map(v=>v.x)))/2,(Math.min(...band.map(v=>v.y))+Math.max(...band.map(v=>v.y)))/2,frontZ);
    const magazines=arcane?[]:result.meshes.filter(m=>m.name.toLowerCase().includes('magazine')).map(mesh=>({mesh,position:mesh.position.clone()}));
    const finishProcessing=new ImageProcessingConfiguration();finishProcessing.toneMappingEnabled=true;finishProcessing.toneMappingType=ImageProcessingConfiguration.TONEMAPPING_ACES;finishProcessing.exposure=1.35;
    const finishCurves=new ColorCurves();finishCurves.globalSaturation=i===0?-85:-72;finishProcessing.colorCurves=finishCurves;finishProcessing.colorCurvesEnabled=true;
    for(const mesh of result.meshes){mesh.renderingGroupId=2;mesh.isPickable=false;mesh.alwaysSelectAsActiveMesh=true;mesh.receiveShadows=false;if(mesh.material){mesh.material=mesh.material.clone(`${definition.id} aged finish`);mesh.material.maxSimultaneousLights=4;mesh.material.albedoColor=i===0?new Color3(.24,.31,.36):new Color3(.28,.30,.29);mesh.material.metallic=.42;mesh.material.roughness=.84;mesh.material.emissiveColor=new Color3(.003,.005,.007);mesh.material.imageProcessingConfiguration=finishProcessing;}}
    const flashMaterial=new StandardMaterial(`${definition.id} muzzle glow`,scene);flashMaterial.disableLighting=true;flashMaterial.emissiveColor=Color3.FromHexString(definition.color);flashMaterial.diffuseColor=flashMaterial.emissiveColor;
    const flash=MeshBuilder.CreateCylinder('muzzle flash',{height:.10,diameterTop:.014,diameterBottom:.065,tessellation:8},scene);flash.parent=rig;flash.rotation.x=Math.PI/2;flash.position.copyFrom(tip.add(new Vector3(0,0,.055)));flash.material=flashMaterial;flash.renderingGroupId=2;flash.isPickable=false;flash.setEnabled(false);
    const muzzle=new PointLight('shot light',tip.add(new Vector3(0,0,.02)),scene);muzzle.parent=rig;muzzle.diffuse=flashMaterial.emissiveColor;muzzle.range=2;muzzle.intensity=0;muzzle.renderPriority=20;
    const glove=new StandardMaterial('서기관 장갑',scene);glove.maxSimultaneousLights=4;glove.diffuseColor=Color3.FromHexString('#303332');glove.emissiveColor=new Color3(.003,.004,.005);glove.specularColor=new Color3(.025,.025,.025);glove.specularPower=12;
    const hand=MeshBuilder.CreateCapsule('쥔 손',{height:.19,radius:.045,tessellation:10},scene);hand.parent=rig;hand.position.set(.015,-.10,-.10);hand.rotation.x=-.35;hand.material=glove;hand.renderingGroupId=2;hand.isPickable=false;
    const crystal=!arcane&&i===0?createToolCrystal(scene,rig):null;
    // CSG introduces fresh faces: use solid aged metal, rather than stretching
    // the imported palette UVs over the carved channels and the plate's sides.
    const sealMetal=!arcane&&i===1?new PBRMaterial('마도구 배지의 닳은 황동',scene):null;
    if(sealMetal){sealMetal.albedoColor=Color3.FromHexString('#66543b');sealMetal.metallic=.6;sealMetal.roughness=.62;sealMetal.maxSimultaneousLights=4;sealMetal.useGLTFLightFalloff=true;}
    const engraving=!arcane&&i===1?createCarvedSeal(scene,'연사 마도구의 금속 각인',sealMetal,{color:new Color3(.54,.30,.09)}):null;
    if(engraving){engraving.root.parent=rig;engraving.root.position.set(-.005,.10,-definition.length*.5-.012);engraving.root.scaling.setAll(.13);}
    const viewMeshes=[...result.meshes,hand,...(arcane?arcane.meshes:[]),...(crystal?[crystal.mesh]:[]),...(engraving?engraving.meshes:[])];
    for(const mesh of viewMeshes){mesh.renderingGroupId=2;mesh.isPickable=false;mesh.receiveShadows=false;mesh.metadata={...mesh.metadata,toolVisual:true};}
    if(i===1){const support=hand.clone('받치는 손');support.parent=rig;support.position.set(-.04,-.09,.20);support.rotation.z=.5;viewMeshes.push(support);}
    const viewHands=viewMeshes.filter(m=>m===hand||m.name==='받치는 손');
    // A restrained camera-space key and rim keep dark iron readable without
    // lifting the room's shadows or letting the muzzle replace a clue light.
    for(const light of scene.lights)if(light!==muzzle)light.excludedMeshes.push(...viewMeshes);
    muzzle.includedOnlyMeshes=viewMeshes;
    const keyLight=new PointLight('viewmodel soft key',new Vector3(-.3,.32,-.62),scene);keyLight.parent=rig;keyLight.diffuse=new Color3(.55,.66,.79);keyLight.intensity=1.15;keyLight.range=2;keyLight.renderPriority=15;keyLight.includedOnlyMeshes=viewMeshes;
    const rim=new PointLight('viewmodel worn edge',new Vector3(.35,.10,.24),scene);rim.parent=rig;rim.diffuse=i===0?new Color3(.47,.65,.78):new Color3(.83,.68,.46);rim.intensity=.85;rim.range=1.4;rim.renderPriority=14;rim.includedOnlyMeshes=viewMeshes;
    rig.setEnabled(i===0);
    weapons.push({...definition,rig,flash,muzzle,tip,arcane,magazines,crystal,engraving,viewMeshes,viewHands,runeCharge:0,ammo:definition.capacity,clips:result.animationGroups.map(g=>g.name),sourceSize:sourceSize.asArray()});
  }
  $('weapon-hud').hidden=false;
  const api={
    unlock(){sound.unlock();},
    hold(){held=true;emptyLatch=false;api.fire();},release(){held=false;emptyLatch=false;},
    audioStream:()=>sound.stream(),
    pauseAudio:()=>sound.pause(),
    setPerspective(mode){thirdPerson=mode==='third';for(const w of weapons){w.rig.parent=thirdPerson?thirdPersonAnchor:camera;w.rig.scaling.setAll(thirdPerson?.85:1);for(const mesh of w.viewMeshes)mesh.renderingGroupId=thirdPerson?0:2;for(const hand of w.viewHands)hand.setEnabled(!thirdPerson);w.flash.renderingGroupId=thirdPerson?0:2;}},
    gripTargets(){const w=weapons[selected];w.rig.computeWorldMatrix(true);const matrix=w.rig.getWorldMatrix(),grips=w.arcane?.grips(),trigger=Vector3.TransformCoordinates(grips?.trigger||new Vector3(.015,-.10,-.10),matrix),support=Vector3.TransformCoordinates(grips?.support||new Vector3(-.16,-.03,.10),matrix);if(thirdPerson&&reloadTime>0&&w.magazines.length){w.magazines[0].mesh.computeWorldMatrix(true);Vector3.LerpToRef(support,w.magazines[0].mesh.getAbsolutePosition(),Math.sin((1-reloadTime/w.reload)*Math.PI),support);}return {trigger:trigger.asArray(),support:support.asArray(),relaxLeft:grips?.relaxLeft&&reloadTime===0};},
    select(index){if(index===selected||!weapons[index])return;sound.cancelReload();weapons[selected].rig.setEnabled(false);for(const m of weapons[selected].magazines)m.mesh.position.copyFrom(m.position);selected=index;weapons[selected].rig.setEnabled(true);equip=weapons[selected].equip;reloadTime=0;cooldown=0;kick=0;held=false;flashTime=0;stats.switches++;},
    reload(automatic=false){const w=weapons[selected];if(equip>0||reloadTime>0||w.ammo===w.capacity)return;reloadTime=w.reload;held=false;sound.reloadStart(automatic?.095:0,w.id,w.reload);stats.reloads++;},
    fire(){const w=weapons[selected];if(equip>0||reloadTime>0||cooldown>0)return;if(!w.ammo){if(!emptyLatch){sound.empty();emptyLatch=true;}api.reload(true);return;}w.ammo--;cooldown=w.interval;kick=Math.min(.15,kick+w.kick);flashTime=.065;stats.shots++;w.rig.computeWorldMatrix(true);pendingShots.push({weapon:w,origin:Vector3.TransformCoordinates(w.tip,w.rig.getWorldMatrix())});sound.play(w.sound);},
    toggleMute(){muted=!muted;sound.setMuted(muted);return muted;},
    reset(){sound.stopAll();pendingShots.length=0;onReset();emptyLatch=false;for(const w of weapons){w.ammo=w.capacity;w.rig.setEnabled(false);for(const m of w.magazines)m.mesh.position.copyFrom(m.position);}selected=0;weapons[0].rig.setEnabled(true);equip=.45;reloadTime=0;cooldown=0;kick=0;flashTime=0;held=false;},
    tick(dt,moving,blocked){const w=weapons[selected];if(!blocked){clock+=dt;equip=Math.max(0,equip-dt);cooldown=Math.max(0,cooldown-dt);flashTime=Math.max(0,flashTime-dt);kick*=Math.exp(-w.recover*dt);if(reloadTime>0){reloadTime=Math.max(0,reloadTime-dt);if(reloadTime===0){w.ammo=w.capacity;sound.reloadComplete(w.id);}}if(held)api.fire();}
      const progress=reloadTime>0?1-reloadTime/w.reload:0,reload=Math.sin(progress*Math.PI);
      const lowered=equip>0?Math.pow(equip/w.equip,2):0;
      const bob=moving?Math.sin(clock*(selected===0?10:8))*(selected===0?.009:.006):Math.sin(clock*(selected===0?2:1.4))*.002;
      w.runeCharge=Math.min(1,.06+reload*.94+flashTime*7);w.crystal?.update(w.runeCharge);w.engraving?.setLevel(w.runeCharge);
      w.arcane?.update({charge:w.runeCharge,reload,flash:flashTime,ammo:w.ammo});
      if(thirdPerson){w.rig.position.set(0,-lowered*.06-reload*.025,-kick*.12);w.rig.rotation.set(-kick*.6+reload*.10+lowered*.12,0,reload*(selected===0?-.10:.08));}
      else if(w.arcane){const swing=Math.min(1,kick/w.kick);w.rig.position.set(selected===0?.28:.22,(selected===0?-.24:-.12)-lowered*.40-reload*.025+bob*.6,(selected===0?.65:.88)-swing*.025+lowered*.10);w.rig.rotation.set((selected===0?-.18:-.03)+reload*.07-swing*.08,selected===0?-.24:-.18,(selected===0?-.10:.03)+swing*(selected===0?-.18:.04)+reload*.04);const grips=w.arcane.grips();w.viewHands[0].position.copyFrom(grips.trigger.add(new Vector3(0,-.055,0)));if(w.viewHands[1])w.viewHands[1].position.copyFrom(grips.support.add(new Vector3(0,-.055,0)));}
      else{w.rig.position.set(selected===0?.25:.21,-.24-lowered*.48-reload*.13+bob,w.depth-kick+lowered*.10);w.rig.rotation.set(-kick*1.5+reload*.32+lowered*.7,selected===0?-.025:.015,reload*(selected===0?-.45:.32));}
      for(const magazine of w.magazines)magazine.mesh.position.copyFrom(magazine.position.add(new Vector3(0,-reload*.17,0)));
      if(!blocked)while(pendingShots.length){const shot=pendingShots.shift();shot.weapon.rig.computeWorldMatrix(true);onShot({id:shot.weapon.id,origin:shot.weapon===w?Vector3.TransformCoordinates(w.tip,w.rig.getWorldMatrix()):shot.origin});}
      w.flash.setEnabled(!blocked&&flashTime>0);w.flash.scaling.x=.6+flashTime*7;w.flash.scaling.z=.6+flashTime*7;w.flash.rotation.z=0;w.muzzle.intensity=!blocked&&flashTime>0?flashTime*48:0;
      $('crosshair').classList.toggle('firing',!blocked&&flashTime>0);$('weapon-title').textContent=w.title;$('ammo').textContent=`${String(w.ammo).padStart(2,'0')} / ${w.capacity}`;$('weapon-state').textContent=equip>0?'꺼내는 중':reloadTime>0?'에너지 충전':!w.ammo?`${getKeyLabel('reload')} 충전`:'준비';
    },
    snapshot(){const w=weapons[selected];return {id:w.id,title:w.title,ammo:w.ammo,state:equip>0?'equipping':reloadTime>0?'reloading':flashTime>0?'firing':'ready',perspective:thirdPerson?'third':'first',held,recoil:kick,reloadProgress:reloadTime?1-reloadTime/w.reload:0,modelPosition:w.rig.position.asArray(),muzzle:{tip:w.tip.asArray(),flash:w.flash.position.asArray(),group:w.flash.renderingGroupId,enabled:w.flash.isEnabled(),intensity:w.muzzle.intensity},arcane:{form:w.arcane?.form||(w.crystal?'faceted-crystal':'engraved-metal'),charge:w.runeCharge},audio:sound.snapshot(),sourceClips:w.clips,models:weapons.map(w=>({id:w.id,ammo:w.ammo,sourceClips:w.clips,sourceSize:w.sourceSize})),...stats};}
  };
  return api;
}
