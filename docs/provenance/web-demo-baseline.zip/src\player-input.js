// Pointer Lock is requested only by the explicit entry/resume button. The
// unlocked fallback also looks without holding a mouse button, within canvas.
import {canonicalKey} from './preferences.js';
export function createPlayerInput({canvas,preferences,canPlay,onLook,onAction,onPause,onMode,onFire,onRelease}) {
  const keys=new Set(),stats={lockAttempts:0,lockSuccesses:0,lockFailures:0,lookEvents:0};
  let mode='idle',previous=null,ignoreFireUntil=0,request=0,timer=null,lastError='',lastErrorMessage='',outside=false,sessionFree=false,canvasRetryUsed=false;
  const lockDocument=()=>canvas.ownerDocument,locked=()=>lockDocument().pointerLockElement===canvas;
  const setMode=value=>{mode=value;canvas.dataset.input=value;previous=null;onMode(value);};
  function clear(){keys.clear();previous=null;onRelease();}
  function fallback(error,token=request){if(error?.message){lastErrorMessage=error.message;lastError=error.name;}if(token!==request||!canPlay()||locked())return;if(mode==='requesting'){stats.lockFailures++;lastError=error?.name||'PointerLockUnavailable';}clearTimeout(timer);setMode('free-look');}
  const api={keys,
    activate(retrying=false){clear();outside=false;lastError='';lastErrorMessage='';if(!retrying)canvasRetryUsed=false;ignoreFireUntil=performance.now()+180;canvas.focus({preventScroll:true});const token=++request;if(!preferences.get().pointerLock||sessionFree){setMode('free-look');return;}setMode('requesting');stats.lockAttempts++;
      try{if(!canvas.requestPointerLock){fallback({name:'Unsupported'},token);return;}const pending=canvas.requestPointerLock();pending?.catch(error=>fallback(error,token));timer=setTimeout(()=>fallback({name:'NoLockGranted'},token),1600);}catch(error){fallback(error,token);}
    },
    deactivate(){request++;clearTimeout(timer);clear();setMode('idle');if(locked())lockDocument().exitPointerLock();},
    retry(){if(canPlay()){sessionFree=false;canvasRetryUsed=true;api.activate(true);}},
    chooseFree(){sessionFree=true;outside=false;clear();ignoreFireUntil=performance.now()+180;setMode('free-look');canvas.focus({preventScroll:true});},
    clear,
    down:action=>keys.has(preferences.get().bindings[action]),
    snapshot:()=>({mode,locked:locked(),outside,captureChoice:locked()?'locked':!preferences.get().pointerLock?'explicit-free-setting':sessionFree?'explicit-free-session':lastError?'denied':mode,attached:canvas.isConnected,ownerDocumentIsCurrent:canvas.ownerDocument===document,documentFocused:lockDocument().hasFocus(),heldKeys:[...keys],lastError,lastErrorMessage,...stats})
  };
  document.addEventListener('pointerlockchange',()=>{if(locked()){if(!canPlay()){lockDocument().exitPointerLock();return;}clearTimeout(timer);if(mode!=='locked')stats.lockSuccesses++;clear();setMode('locked');}else if(mode==='locked'&&canPlay()){clear();onPause('unlock');}});
  document.addEventListener('pointerlockerror',()=>{if(mode==='requesting')fallback({name:'PointerLockDenied'});});
  document.addEventListener('mousemove',event=>{if(!canPlay()||!['locked','free-look'].includes(mode))return;let dx,dy;
    if(mode==='locked'){dx=event.movementX;dy=event.movementY;}
    else{if(event.target!==canvas){previous=null;return;}if(!previous){previous=[event.clientX,event.clientY];return;}dx=event.clientX-previous[0];dy=event.clientY-previous[1];previous=[event.clientX,event.clientY];}
    if(Number.isFinite(dx)&&Number.isFinite(dy)&&(dx||dy)){onLook(dx,dy);stats.lookEvents++;}
  });
  canvas.addEventListener('pointerenter',()=>{previous=null;});
  canvas.addEventListener('pointerleave',()=>{if(mode==='free-look'){outside=true;clear();}});
  canvas.addEventListener('contextmenu',event=>event.preventDefault());
  canvas.addEventListener('pointerdown',event=>{if(event.button!==0||!canPlay())return;if(mode==='free-look'&&lastError&&!sessionFree&&preferences.get().pointerLock){if(!canvasRetryUsed){canvasRetryUsed=true;api.activate(true);}return;}if(mode==='free-look'&&outside){outside=false;clear();ignoreFireUntil=performance.now()+180;canvas.focus({preventScroll:true});return;}if(['locked','free-look'].includes(mode)&&performance.now()>=ignoreFireUntil){canvas.focus();onFire();}});
  document.addEventListener('pointerup',event=>{if(event.button===0)onRelease();});
  canvas.addEventListener('pointerup',event=>{if(event.button===0)onRelease();});
  document.addEventListener('pointercancel',clear);
  document.addEventListener('pointerdown',event=>{if(event.target.closest?.('button'))clear();},true);
  window.addEventListener('keydown',event=>{
    if(event.code==='Escape'||event.code==='Tab'){if(canPlay()){event.preventDefault();clear();onPause('menu');}return;}
    if(!canPlay()||event.target.closest?.('button,input,textarea,select'))return;
    const code=canonicalKey(event.code),action=Object.keys(preferences.get().bindings).find(id=>preferences.get().bindings[id]===code);if(!action)return;event.preventDefault();
    keys.add(code);if(!event.repeat)onAction(action);
  });
  window.addEventListener('keyup',event=>keys.delete(canonicalKey(event.code)));
  window.addEventListener('blur',()=>{clear();if(canPlay())onPause('blur');});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){clear();if(canPlay())onPause('blur');}});
  let requestedLock=preferences.get().pointerLock;preferences.subscribe(value=>{if(value.pointerLock!==requestedLock){sessionFree=false;requestedLock=value.pointerLock;}});
  return api;
}
