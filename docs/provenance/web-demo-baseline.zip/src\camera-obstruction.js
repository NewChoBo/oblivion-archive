// Sweep the camera's padded near-plane volume along its complete shoulder arm.
// A ray alone would allow the screen corners to cross a shelf or a wall.
export function clearCameraFraction(origin,offset,boxes,radius=.18){
  let closest=1;
  for(const box of boxes){let enter=0,leave=1,hit=true;
    for(let axis=0;axis<3;axis++){
      const low=box.min[axis]-radius,high=box.max[axis]+radius,step=offset[axis];
      if(Math.abs(step)<1e-8){if(origin[axis]<low||origin[axis]>high){hit=false;break;}continue;}
      let first=(low-origin[axis])/step,last=(high-origin[axis])/step;if(first>last)[first,last]=[last,first];enter=Math.max(enter,first);leave=Math.min(leave,last);if(enter>leave){hit=false;break;}
    }
    if(hit&&leave>=0&&enter<=1)closest=Math.min(closest,Math.max(0,enter-.012));
  }
  return closest;
}
