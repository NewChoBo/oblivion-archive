import {Mesh,MeshBuilder,StandardMaterial,Color3,Vector3,Quaternion,Ray} from '@babylonjs/core';

const align=direction=>{const z=Vector3.Forward(),d=direction.normalize(),cross=Vector3.Cross(z,d),dot=Math.max(-1,Math.min(1,Vector3.Dot(z,d)));return cross.lengthSquared()<1e-8?(dot>0?Quaternion.Identity():Quaternion.RotationAxis(Vector3.Up(),Math.PI)):Quaternion.RotationAxis(cross.normalize(),Math.acos(dot));};
export function createSpellEffects(scene,camera,getPlayerEye){
  const pool=[],events=[],stats={fired:0,hits:0,misses:0,resets:0};let clock=0;
  const materials=[new Color3(.11,.50,.65),new Color3(.62,.36,.08)].map((color,i)=>{const m=new StandardMaterial(`마도구 ${i}의 짧은 잔상`,scene);m.disableLighting=true;m.emissiveColor=color;m.maxSimultaneousLights=4;return m;});
  function effect(mesh,material){mesh.material=material;mesh.isPickable=false;mesh.metadata={spellEffect:true};mesh.renderingGroupId=0;mesh.setEnabled(false);return mesh;}
  for(let i=0;i<10;i++){
    const head=effect(MeshBuilder.CreateSphere('이동하는 빛',{diameter:.025,segments:4},scene),materials[0]),trail=effect(MeshBuilder.CreateBox('짧은 빛의 잔상',{width:.010,height:.010,depth:1},scene),materials[0]);
    const ring=effect(MeshBuilder.CreateTorus('표면에 맺히는 인장',{diameter:.15,thickness:.003,tessellation:20},scene),materials[0]);
    const segments=[],points=[[[0,.5],[0,.28]],[[0,.28],[.2,0]],[[.2,0],[0,-.28]],[[0,-.28],[-.2,0]],[[-.2,0],[0,.28]],[[0,-.28],[0,-.5]]];
    for(const [a,b] of points){const bar=MeshBuilder.CreateBox('인장의 획',{width:Math.hypot(b[0]-a[0],b[1]-a[1])*.15,height:.003,depth:.002},scene);bar.position.set((a[0]+b[0])*.075,(a[1]+b[1])*.075,0);bar.rotation.z=Math.atan2(b[1]-a[1],b[0]-a[0]);segments.push(bar);}
    const glyph=effect(Mesh.MergeMeshes(segments,true,true),materials[0]);glyph.name='표면의 작은 봉인';
    const dust=Array.from({length:4},(_,n)=>effect(MeshBuilder.CreateBox('흩어지는 수정 가루와 금빛 불꽃',{width:.007,height:.025,depth:.007},scene),materials[0]));
    pool.push({head,trail,ring,glyph,dust,active:false,age:0,impactAge:-1});
  }
  const world=mesh=>mesh.isVisible&&mesh.isEnabled()&&mesh.isPickable&&!mesh.metadata?.playerVisual&&!mesh.metadata?.toolVisual&&!mesh.metadata?.spellEffect&&mesh.getTotalVertices()>0;
  function pick(origin,direction,length){return scene.pickWithRay(new Ray(origin,direction,length),world,false);}
  function hide(slot){for(const m of [slot.head,slot.trail,slot.ring,slot.glyph,...slot.dust])m.setEnabled(false);slot.active=false;}
  return {
    fire({id,origin}){
      const kind=id==='blaster-a'?0:1,range=10,look=camera.getForwardRay(range),cameraHit=pick(look.origin,look.direction,range),aim=cameraHit?.hit?cameraHit.pickedPoint:look.origin.add(look.direction.scale(range));
      const eye=getPlayerEye(),toTip=origin.subtract(eye),tipDistance=toTip.length(),obstacle=tipDistance>.01?pick(eye,toTip.normalize(),tipDistance):null;
      let start=origin.clone(),hit,direction;
      if(obstacle?.hit){hit=obstacle;direction=obstacle.pickedPoint.subtract(eye).normalize();start=obstacle.pickedPoint.subtract(direction.scale(.012));}
      else{direction=aim.subtract(start).normalize();hit=pick(start,direction,range);}
      const end=hit?.hit?hit.pickedPoint.clone():start.add(direction.scale(range)),distance=Vector3.Distance(start,end),slot=pool.find(p=>!p.active)||pool.reduce((a,b)=>a.age>b.age?a:b);hide(slot);
      Object.assign(slot,{active:true,kind,start,end,direction,normal:hit?.hit?(hit.getNormal(true)||direction.scale(-1)):Vector3.Up(),distance,travel:0,age:0,impactAge:-1,hit:!!hit?.hit,speed:kind===0?14:22});
      for(const mesh of [slot.head,slot.trail,slot.ring,slot.glyph,...slot.dust]){mesh.material=materials[kind];mesh.visibility=1;}
      slot.head.position.copyFrom(start);slot.head.setEnabled(true);slot.trail.setEnabled(true);stats.fired++;
      const event={number:stats.fired,id,start:start.asArray(),muzzle:origin.asArray(),end:end.asArray(),hit:!!hit?.hit,mesh:hit?.pickedMesh?.name||null,meshId:hit?.pickedMesh?.uniqueId||null,cameraMesh:cameraHit?.pickedMesh?.name||null,muzzleBlocked:!!obstacle?.hit,distance,arrived:false};slot.event=event;events.push(event);if(events.length>60)events.shift();
    },
    update(dt){clock+=dt;for(const slot of pool){if(!slot.active)continue;slot.age+=dt;
      if(slot.impactAge<0){slot.travel=Math.min(slot.distance,slot.travel+slot.speed*dt);const position=slot.start.add(slot.direction.scale(slot.travel)),length=Math.min(slot.kind===0?.28:.42,Math.max(.01,slot.travel));slot.head.position.copyFrom(position);slot.trail.position.copyFrom(position.subtract(slot.direction.scale(length/2)));slot.trail.rotationQuaternion=align(slot.direction);slot.trail.scaling.z=length;
        if(slot.travel>=slot.distance){slot.impactAge=0;slot.head.setEnabled(false);slot.event.arrived=true;if(slot.hit){stats.hits++;const point=slot.end.add(slot.normal.scale(.008)),rotation=align(slot.normal);slot.ring.position.copyFrom(point);slot.ring.rotationQuaternion=rotation.multiply(Quaternion.RotationAxis(Vector3.Right(),Math.PI/2));slot.glyph.position.copyFrom(point);slot.glyph.rotationQuaternion=rotation;slot.ring.setEnabled(slot.kind===0);slot.glyph.setEnabled(slot.kind===0);for(const p of slot.dust){p.position.copyFrom(point);p.setEnabled(true);}}else stats.misses++;}
      }else{slot.impactAge+=dt;const life=slot.kind===0?.30:.22,fade=Math.max(0,1-slot.impactAge/life);slot.trail.visibility=Math.max(0,1-slot.impactAge/.06);slot.ring.visibility=fade;slot.glyph.visibility=fade;slot.ring.scaling.setAll(.70+(1-fade)*.40);slot.glyph.scaling.setAll(.70+(1-fade)*.40);
        for(const [index,p] of slot.dust.entries()){const angle=index*Math.PI/2+.35,local=new Vector3(Math.cos(angle)*slot.impactAge*.25,Math.sin(angle)*slot.impactAge*.25,slot.impactAge*.12),rotation=align(slot.normal);p.position.copyFrom(slot.end.add(slot.normal.scale(.01)).add(local.applyRotationQuaternion(rotation)));p.rotation.z=angle+clock*2;p.visibility=fade;}
        if(slot.impactAge>=life)hide(slot);
      }
    }},
    reset(){for(const p of pool)hide(p);events.length=0;stats.fired=0;stats.hits=0;stats.misses=0;stats.resets++;},
    ready:()=>Promise.all(materials.map((m,i)=>m.forceCompilationAsync(pool[i].head))),
    snapshot:()=>({...stats,active:pool.filter(p=>p.active).length,travelling:pool.filter(p=>p.active&&p.impactAge<0).length,events:events.map(e=>({...e}))})
  };
}
