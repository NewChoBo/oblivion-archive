import {TransformNode,MeshBuilder,PBRMaterial,Color3,Vector3,Quaternion,Matrix} from '@babylonjs/core';
import {clearCameraFraction} from './camera-obstruction.js';

function pointBone(node,from,to){node.position.copyFrom(from);const direction=to.subtract(from).normalize(),down=new Vector3(0,-1,0),cross=Vector3.Cross(down,direction),dot=Math.max(-1,Math.min(1,Vector3.Dot(down,direction)));node.rotationQuaternion=cross.lengthSquared()<1e-8?(dot>0?Quaternion.Identity():Quaternion.RotationAxis(Vector3.Right(),Math.PI)):Quaternion.RotationAxis(cross.normalize(),Math.acos(dot));}
function solveLimb(upper,lower,start,target,pole,length=.34){const delta=target.subtract(start),distance=Math.max(.025,Math.min(length*1.99,delta.length())),axis=delta.normalize(),bend=pole.subtract(axis.scale(Vector3.Dot(pole,axis))).normalize(),middle=start.add(axis.scale(distance/2)).add(bend.scale(Math.sqrt(Math.max(0,length*length-distance*distance/4))));pointBone(upper,start,middle);pointBone(lower,middle,target);}

// Project-authored, articulated archive keeper; no external character/license.
export function createPlayerView(scene,camera,body,collisionBoxes){
  const root=new TransformNode('서기관 — 3인칭 플레이어',scene),meshes=[];
  const finish=(name,color,metallic=0,roughness=.9)=>{const m=new PBRMaterial(name,scene);m.albedoColor=Color3.FromHexString(color);m.metallic=metallic;m.roughness=roughness;m.maxSimultaneousLights=4;m.useGLTFLightFalloff=true;return m;};
  const cloth=finish('서기관의 청회색 여행복','#25343c'),mantle=finish('닳은 후드와 어깨 망토','#34464b'),leather=finish('장갑과 여행 가죽','#2e2a25'),trim=finish('서기관의 황동 버클','#84724e',.55,.65),face=finish('후드 안의 회빛 가면','#8b8e81');
  function part(name,kind,size,position,mat,parent=root){const mesh=kind==='box'?MeshBuilder.CreateBox(name,{width:size[0],height:size[1],depth:size[2]},scene):kind==='sphere'?MeshBuilder.CreateSphere(name,{diameter:1,segments:8},scene):MeshBuilder.CreateCylinder(name,{height:size[1],diameterTop:size[0],diameterBottom:size[2],tessellation:8},scene);if(kind==='sphere')mesh.scaling.set(...size);mesh.parent=parent;mesh.position.set(...position);mesh.material=mat;mesh.receiveShadows=true;mesh.isPickable=false;mesh.metadata={playerVisual:true};meshes.push(mesh);return mesh;}
  part('여행복 몸통','cylinder',[.43,.48,.36],[0,1.12,0],cloth);
  part('짧은 코트 자락','cylinder',[.36,.40,.50],[0,.76,0],cloth);
  part('어깨 망토','cylinder',[.38,.13,.62],[0,1.36,0],mantle);
  part('후드','sphere',[.43,.47,.42],[0,1.55,0],mantle);
  part('후드 속 가면','sphere',[.26,.30,.07],[0,1.54,.194],face);
  part('목깃','cylinder',[.19,.12,.24],[0,1.36,.015],leather);
  part('가죽 허리띠','box',[.39,.06,.32],[0,.94,.01],leather);
  part('허리띠 버클','box',[.07,.07,.025],[0,.94,.18],trim);
  const badge=part('기록관의 가슴 인장','box',[.08,.09,.035],[0,1.23,.22],trim);badge.rotation.z=Math.PI/4;
  part('기록 가방','box',[.29,.31,.13],[0,1.07,-.23],leather);
  for(const side of [-1,1])part('가방 어깨끈','box',[.036,.38,.03],[side*.13,1.21,-.215],trim);
  const legs=[],arms=[];
  for(const side of [-1,1]){
    const hip=new TransformNode('다리 관절',scene);hip.parent=root;hip.position.set(side*.12,.68,0);
    part('여행복 바지','cylinder',[.15,.34,.13],[0,-.17,0],cloth,hip);
    const knee=new TransformNode('무릎 관절',scene);knee.parent=root;
    part('가죽 각반','cylinder',[.135,.34,.11],[0,-.17,0],leather,knee);
    const boot=part('여행 장화','box',[.15,.15,.26],[side*.12,.075,.055],leather);legs.push({hip,knee,boot,side,foot:new Vector3(side*.12,.075,0)});
    const shoulder=new TransformNode('마도구를 든 어깨',scene);shoulder.parent=root;shoulder.position.set(side*.25,1.28,0);
    part('코트 소매','cylinder',[.15,.31,.12],[0,-.155,0],cloth,shoulder);
    const elbow=new TransformNode('팔꿈치 관절',scene);elbow.parent=root;
    part('팔 보호구','cylinder',[.12,.31,.10],[0,-.155,0],leather,elbow);
    part('마도구를 받치는 장갑','sphere',[.12,.14,.12],[0,-.31,0],leather,elbow);arms.push({shoulder,elbow,side});
  }
  const toolAnchor=new TransformNode('서기관 손의 실제 마도구',scene);toolAnchor.parent=root;toolAnchor.position.set(.30,1.18,.32);
  let mode='first',clock=0,stride=0,phase=0,directionX=0,directionZ=1,running=false,cameraLength=2.5,obstructed=false,opacity=1,walking=false;
  root.setEnabled(false);
  const bounds=()=>collisionBoxes.map(mesh=>{mesh.computeWorldMatrix(true);const b=mesh.getBoundingInfo().boundingBox;return {min:b.minimumWorld.asArray(),max:b.maximumWorld.asArray()};});
  let boxes=null;
  return {root,meshes,toolAnchor,
    setMode(value){mode=value;root.setEnabled(mode==='third');cameraLength=2.5;},
    update(dt,{yaw,pitch,moving,distance=0,speed=0,airborne=false,localX=0,localZ=0,paused=false}){
      if(!paused)clock+=dt;stride+=(Number(moving)-stride)*(1-Math.exp(-dt*12));walking=moving;if(moving){directionX=localX;directionZ=localZ;}
      running=speed>3.4;const cycleLength=running?1.7:1.25,stance=running?.42:.52,reach=cycleLength*stance/2;
      if(!airborne)phase=(phase+distance/cycleLength)%1;const bounce=airborne?0:Math.abs(Math.sin(phase*Math.PI*2))*(running?.035:.018)*stride;
      root.position.set(body.position.x,body.position.y-.8484+bounce,body.position.z);root.rotation.y=yaw;
      for(const leg of legs){const p=(phase+(leg.side<0?.5:0))%1,swing=(p-stance)/(1-stance),along=p<stance?reach*(1-2*p/stance):reach*(-1+2*(swing*swing*(3-2*swing))),lift=p<stance?0:Math.sin(swing*Math.PI)*(running?.19:.12);leg.foot.set(leg.side*.12+directionX*along*stride,.075-bounce+lift*stride,directionZ*along*stride);solveLimb(leg.hip,leg.knee,new Vector3(leg.side*.12,.68,0),leg.foot,new Vector3(0,-.1,1));leg.boot.position.copyFrom(leg.foot.add(new Vector3(0,0,.055)));leg.boot.rotation.y=Math.atan2(directionX,Math.abs(directionZ)||.8)*stride*.55;}
      if(airborne)for(const leg of legs){leg.foot.set(leg.side*.12,.19+(leg.side>0?.06:0),.08);solveLimb(leg.hip,leg.knee,new Vector3(leg.side*.12,.68,0),leg.foot,new Vector3(0,-.1,1));leg.boot.position.copyFrom(leg.foot.add(new Vector3(0,0,.055)));leg.boot.rotation.y=0;}
      toolAnchor.position.y=1.18+Math.sin(clock*1.5)*.003;toolAnchor.rotation.x=pitch;
      const eye=body.position.add(new Vector3(0,.72,0));camera.rotation.set(pitch,yaw,0);
      if(mode==='first'){camera.position.copyFrom(eye);obstructed=false;return;}
      boxes??=bounds();const direction=new Vector3(Math.sin(yaw)*Math.cos(pitch),-Math.sin(pitch),Math.cos(yaw)*Math.cos(pitch)),right=new Vector3(Math.cos(yaw),0,-Math.sin(yaw));
      const arm=direction.scale(-2.5).add(right.scale(.62)).add(new Vector3(0,.12,0));arm.y=Math.max(.22-eye.y,Math.min(3.75-eye.y,arm.y));
      const fraction=clearCameraFraction(eye.asArray(),arm.asArray(),boxes,.20),wanted=arm.length()*fraction;
      cameraLength=wanted<cameraLength?wanted:cameraLength+(wanted-cameraLength)*Math.min(1,dt*6);camera.position.copyFrom(eye.add(arm.normalize().scale(cameraLength)));
      obstructed=fraction<.995;opacity=Math.max(0,Math.min(1,(cameraLength-.85)/.70));for(const mesh of meshes)mesh.visibility=opacity;
    },
    poseArms(targets){if(mode!=='third'||!targets)return;root.computeWorldMatrix(true);const inverse=Matrix.Invert(root.getWorldMatrix());for(const arm of arms){const target=arm.side<0&&targets.relaxLeft?new Vector3(-.22,.88,.10):Vector3.TransformCoordinates(Vector3.FromArray(arm.side>0?targets.trigger:targets.support),inverse);solveLimb(arm.shoulder,arm.elbow,new Vector3(arm.side*.25,1.28,0),target,new Vector3(arm.side*.6,-1,-.2),.31);}},
    snapshot:()=>({mode,visible:root.isEnabled(),walking,running,stride,gaitPhase:phase,feet:legs.map(leg=>leg.foot.asArray()),opacity,cameraDistance:cameraLength,obstructed,toolAnchor:toolAnchor.getAbsolutePosition().asArray(),meshCount:meshes.length})
  };
}
