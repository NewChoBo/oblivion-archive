export function createSession(definition) {
  let completed=0;
  const records=[];
  return {
    get completed() { return completed; },
    get done() { return completed===definition.steps.length; },
    get current() { return definition.steps[completed]||null; },
    get records() { return [...records]; },
    canUse(target,position) {
      const step=definition.steps[completed];
      return Boolean(step&&target===step.target&&Math.hypot(position.x-step.position[0],position.z-step.position[2])<=step.range);
    },
    use(target,position) {
      if(!this.canUse(target,position))return null;
      const step=definition.steps[completed++];records.push(step.record);return step;
    },
    reset() { completed=0;records.length=0; }
  };
}
