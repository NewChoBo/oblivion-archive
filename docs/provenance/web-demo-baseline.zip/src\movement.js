export const WALK_SPEED=3,SPRINT_SPEED=5;
export function moveCollider(body,displacement){body.computeWorldMatrix(true);body.moveWithCollisions(displacement);}
export function movementIntent(input,yaw){const x=Number(input.down('right'))-Number(input.down('left')),z=Number(input.down('forward'))-Number(input.down('back')),length=Math.hypot(x,z),running=length>0&&input.down('sprint'),speed=length?(running?SPRINT_SPEED:WALK_SPEED):0;return {x:length?(Math.sin(yaw)*z+Math.cos(yaw)*x)/length*speed:0,z:length?(Math.cos(yaw)*z-Math.sin(yaw)*x)/length*speed:0,localX:x/(length||1),localZ:z/(length||1),speed,running};}
export function movementSteps(seconds){const elapsed=Math.max(0,Math.min(1,seconds)),count=Math.max(1,Math.ceil(elapsed/.025));return {elapsed,count,step:elapsed/count};}
