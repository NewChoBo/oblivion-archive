import './style.css';
import { Engine,Scene,SceneLoader,Vector3,Color3,Color4,HemisphericLight,DirectionalLight,PointLight,SpotLight,MeshBuilder,PBRMaterial,Texture,ShadowGenerator,FreeCamera,TransformNode,ColorCurves,ImageProcessingConfiguration } from '@babylonjs/core';
import '@babylonjs/loaders/glTF/2.0/glTFLoader.js';
import {createSession} from './session.js';
import {createWeapons} from './weapons.js';
import {createArchiveMagic} from './arcane-art.js';
import {createPlayerInput} from './player-input.js';
import {createPlayerView} from './player-view.js';
import {createPreferences,createSettingsPanel} from './preferences.js';
import {movementIntent,movementSteps,moveCollider,WALK_SPEED,SPRINT_SPEED} from './movement.js';
import {createJumpMotor} from './jump-motor.js';
import {createSpellEffects} from './spell-effects.js';
import {hasGroundContact} from './collider-contact.js';
const $=id=>document.getElementById(id),canvas=$('game');
const definition=await fetch('./data/library.json').then(r=>{if(!r.ok)throw Error('장면 데이터를 불러오지 못했습니다.');return r.json();});
const session=createSession(definition);
const preferences=createPreferences();
const jumpMotor=createJumpMotor();
let lastFrameTime=performance.now(),movementRuntime={speed:0,running:false,elapsed:0,substeps:0};
let started=false,paused=false,ready=false,noticeUntil=0,weaponSystem=null,nearest=null,walkDistance=0,restorationStart=-1;
const engine=new Engine(canvas,true,{preserveDrawingBuffer:true,stencil:true,antialias:true});
engine.setHardwareScalingLevel(Math.max(1,window.devicePixelRatio/1.5));
const scene=new Scene(engine);scene.clearColor=new Color4(.008,.014,.024,1);scene.collisionsEnabled=true;
scene.fogMode=Scene.FOGMODE_EXP2;scene.fogColor=new Color3(.018,.029,.044);scene.fogDensity=.045;
const imageProcessing=scene.imageProcessingConfiguration;
imageProcessing.toneMappingEnabled=true;imageProcessing.toneMappingType=ImageProcessingConfiguration.TONEMAPPING_ACES;
imageProcessing.exposure=1.6;imageProcessing.contrast=1;
const nightCurves=new ColorCurves();nightCurves.globalSaturation=-20;nightCurves.shadowsSaturation=-15;
imageProcessing.colorCurves=nightCurves;imageProcessing.colorCurvesEnabled=true;
const camera=new FreeCamera('서기관의 시점',new Vector3(0,1.6,-4.5),scene);camera.minZ=.04;camera.maxZ=55;camera.fov=1.12;
camera.inputs.clear();scene.activeCamera=camera;
const body=MeshBuilder.CreateBox('player-collision',{width:.5,height:1.7,depth:.5},scene);body.position.set(0,.86,-4.5);body.isVisible=false;body.ellipsoid=new Vector3(.25,.84,.25);
let yaw=0,pitch=.06,viewMode='first';
const ambient=new HemisphericLight('심야의 청회색 간접광',new Vector3(0,1,0),scene);ambient.intensity=.46;ambient.diffuse=new Color3(.42,.56,.72);ambient.groundColor=new Color3(.09,.085,.08);
const sun=new DirectionalLight('벽 틈으로 스민 달빛',new Vector3(.3,-.7,.5),scene);sun.position.set(-3,8,-4);sun.intensity=.24;sun.diffuse=new Color3(.42,.58,.76);sun.shadowMinZ=.1;sun.shadowMaxZ=22;sun.shadowFrustumSize=18;
const shadow=new ShadowGenerator(1024,sun);shadow.usePercentageCloserFiltering=true;shadow.filteringQuality=ShadowGenerator.QUALITY_LOW;shadow.bias=.0015;shadow.normalBias=.018;shadow.setDarkness(.25);
scene.setRenderingAutoClearDepthStencil(2,true,true,true);
scene.setRenderingAutoClearDepthStencil(3,true,true,true);
const C=hex=>Color3.FromHexString(hex);
function material(name,color,emission=null){const m=new PBRMaterial(name,scene);m.maxSimultaneousLights=4;m.albedoColor=C(color);m.metallic=0;m.roughness=.9;m.useGLTFLightFalloff=true;if(emission)m.emissiveColor=C(emission);return m;}
const wood=material('묵은 목재','#40382e'),darkWood=material('오래된 프레임','#242a2d'),stone=material('회청색 돌','#3b454d'),plaster=material('벽의 그늘','#2c3842'),brass=material('산화된 황동','#78674c'),paper=material('기록지','#c2b494'),red=material('빛바랜 포도주색 천','#28212a');
brass.metallic=.60;brass.roughness=.68;red.roughness=1;
const collisionBoxes=[];
function box(name,p,size,mat,solid=false){const m=MeshBuilder.CreateBox(name,{width:size[0],height:size[1],depth:size[2]},scene);m.position.copyFromFloats(...p);m.material=mat;m.receiveShadows=true;if(solid){m.checkCollisions=true;collisionBoxes.push(m);}return m;}
function point(name,p,color,intensity,range){const l=new PointLight(name,Vector3.FromArray(p),scene);l.diffuse=C(color);l.intensity=intensity;l.range=range;return l;}
const floorMat=material('먼지가 앉은 묵은 마루','#697075');floorMat.albedoTexture=new Texture('./assets/polyhaven/old_wooden_floor_01_diff_1k.jpg',scene);floorMat.albedoTexture.uScale=4.5;floorMat.albedoTexture.vScale=7;floorMat.bumpTexture=new Texture('./assets/polyhaven/old_wooden_floor_01_nor_gl_1k.jpg',scene);floorMat.bumpTexture.uScale=4.5;floorMat.bumpTexture.vScale=7;floorMat.bumpTexture.level=.32;floorMat.roughness=.78;floorMat.metallic=.02;
const ground=MeshBuilder.CreateGround('마루',{width:9,height:14},scene);ground.position.z=1;ground.material=floorMat;ground.checkCollisions=true;ground.receiveShadows=true;
box('서쪽 벽',[-4.55,2,1],[.25,4,14],plaster,true);box('동쪽 벽',[4.55,2,1],[.25,4,14],plaster,true);box('입구 벽',[0,2,-6],[9,4,.25],plaster,true);
box('빛을 삼키는 천장',[0,4.02,1],[9,.08,14],darkWood,true);
box('문 왼쪽',[-3,2,7],[3,4,.4],stone,true);box('문 오른쪽',[3,2,7],[3,4,.4],stone,true);box('문 위',[0,3.5,7],[3,1,.4],stone,true);box('문 너머',[0,1.9,7.9],[3,3.8,.3],darkWood,true);
for(const side of [-1,1])for(const z of [-4.4,-1.4,1.6,4.6]){
  box('기둥',[side*4.27,1.85,z],[.28,3.7,.35],darkWood);box('기둥 머리',[side*4.27,3.45,z],[.5,.18,.55],wood);
  box('황동 벽등',[side*4.05,2.35,z],[.18,.35,.21],brass);box('등불',[side*3.94,2.35,z],[.1,.23,.14],material('그을린 등불 유리','#6f5840','#24190f'));
  point('벽에 남은 작은 온기',[side*3.7,2.4,z],'#bd8a52',z===1.6?.30:.12,2.8);
}
for(const z of [-4.4,1.6,6.2])box('들보',[0,3.8,z],[8.6,.25,.32],darkWood);
for(const y of [.12,3.4])for(const side of [-1,1])box('벽 마감',[side*4.4,y,1],[.11,.15,14],wood);
for(const side of [-1,1])box('열람문 기둥',[side*1.4,1.5,6.8],[.34,3,.52],wood,true);
const portal=box('잠든 기억의 문',[0,1.5,7.57],[2.4,2.8,.07],material('문 안개','#17232d','#010203'));
const portalLight=point('복원 후 문턱의 냉광',[0,2.1,6.8],'#79aabd',0,4.5);portalLight.setEnabled(false);
const rug=box('붉은 러그',[0,.008,-.5],[2.3,.015,3.8],red);for(const x of [-1.03,1.03])box('러그 가장자리',[x,.02,-.5],[.025,.015,3.5],brass);
// Existing Unity furniture footprints are retained in this representative room.
box('기록 책상',[.4,.59,1.8],[2.4,1.18,1.1],wood,true);
box('책상 위판',[.4,1.21,1.8],[2.56,.12,1.22],darkWood);
for(const x of [-.6,1.4])box('책상 서랍',[x,.7,1.21],[.46,.21,.055],darkWood);
box('원고',[.24,1.285,1.58],[.54,.015,.34],paper);
box('이야기 조각 받침대',[1.5,.42,-3.5],[.65,.84,.6],wood,true);box('받침대 위판',[1.5,.87,-3.5],[.74,.08,.66],darkWood);
const palette=['#34434a','#4c3437','#796c50','#454b3e','#373641','#66523d'].map((color,i)=>material(`빛바랜 책 표지 ${i}`,color));
const spineMark=material('빛바랜 책등의 장식','#a18d68');spineMark.roughness=1;
function book(name,p,size,index,rotation=0){const b=box(name,p,size,palette[index%palette.length]);b.rotation.z=rotation;if(index%3===0){const mark=box('읽을 글자가 없는 책등 표식',[0,size[1]*.20,size[2]/2+.004],[size[0]*.65,.048,.006],spineMark);mark.parent=b;}return b;}
const fragment=new TransformNode('이야기 조각',scene);
const fragmentBook=book('남겨진 책',[0,0,0],[.35,.10,.46],2);fragmentBook.parent=fragment;fragment.position.set(1.5,.98,-3.5);
const fragmentLight=point('조각 위에 남은 작은 불빛',[1.5,1.40,-3.5],'#ffca88',12,2.5);
const photograph=new TransformNode('복원된 사진',scene);photograph.position.set(.5,1.3,1.8);
const frame=box('사진 액자',[0,.29,0],[.75,.58,.06],brass);frame.parent=photograph;
const image=box('사진 종이',[0,.29,-.04],[.65,.48,.015],paper);image.parent=photograph;
for(const x of [-.14,.14]){const head=MeshBuilder.CreateSphere('사진 속 사람',{diameter:.11,segments:8},scene);head.parent=photograph;head.position.set(x,.36,-.055);head.scaling.z=.1;head.material=darkWood;const person=box('사진 실루엣',[x,.22,-.055],[.12,.18,.01],darkWood);person.parent=photograph;}
photograph.setEnabled(false);
box('탁상등 받침',[1.22,1.29,1.8],[.25,.08,.25],brass);box('탁상등 대',[1.22,1.52,1.8],[.04,.43,.04],brass);
const shade=MeshBuilder.CreateCylinder('등갓',{height:.32,diameterTop:.25,diameterBottom:.55,tessellation:12},scene);shade.position.set(1.22,1.84,1.8);shade.material=material('낡은 호박색 등갓','#826948','#6b3a0e');
const deskLight=new SpotLight('기록만 비추는 호박색 등불',new Vector3(1.22,1.64,1.8),new Vector3(-.8,-.6,-.2).normalize(),2.25,1.4,scene);deskLight.diffuse=C('#ff9b48');deskLight.intensity=18;deskLight.range=3.8;
ambient.renderPriority=10;sun.renderPriority=8;deskLight.renderPriority=12;fragmentLight.renderPriority=11;portalLight.renderPriority=13;
const archiveMagic=createArchiveMagic(scene);
// A local bounce on the desk models the lamp's indirect warmth without lifting
// the shelves, ceiling or doorway. Collision and interaction meshes stay intact.
const deskBounce=point('기록대 목재의 호박색 반사',[.4,1.18,.72],'#d9924c',.65,2.8);deskBounce.renderPriority=14;
const playerView=createPlayerView(scene,camera,body,collisionBoxes);
const spells=createSpellEffects(scene,camera,()=>body.position.add(new Vector3(0,.72,0)));
deskBounce.includedOnlyMeshes=scene.meshes.filter(m=>['기록 책상','책상 위판','책상 서랍','원고','사진 액자','사진 종이','사진 속 사람','사진 실루엣','등갓'].includes(m.name)||m.name.startsWith('기록대의 금속 인장'));
function updateRestoration(now){const elapsed=restorationStart<0?-1:(now-restorationStart)/1000;const doorLight=archiveMagic.update(elapsed);portalLight.setEnabled(doorLight>0);portalLight.intensity=doorLight*.72;portal.material.emissiveColor=Color3.Lerp(C('#010203'),C('#13343e'),doorLight);portal.material.albedoColor=Color3.Lerp(C('#17232d'),C('#3d5963'),doorLight);}
function toast(text){$('notice').textContent=text;$('notice').classList.add('visible');noticeUntil=performance.now()+4500;}
function refresh(){const step=session.current;$('progress').textContent=session.done?'기록 완료':`${session.completed+1} / 3  서기관의 기록`;$('step-title').textContent=step?.title||'다시 이어진 이야기';$('step-text').textContent=step?.objective||'작은 약속 하나가 망각을 건넜습니다. 서재를 자유롭게 둘러보세요.';[...$('step-dots').children].forEach((el,i)=>el.classList.toggle('done',i<session.completed));$('step-dots').setAttribute('aria-label',`진행 ${session.completed}/3`);
  fragment.setEnabled(session.completed<1);fragmentLight.setEnabled(session.completed<1);
  photograph.setEnabled(session.completed>=2);
  if(session.completed<2)restorationStart=-1;else if(restorationStart<0)restorationStart=performance.now();
  updateRestoration(performance.now());deskLight.intensity=session.completed>=2?20:18;
  shadow.getShadowMap()?.resetRefreshCounter();
}
function interact(){if(!started||paused||!nearest)return;const step=session.use(nearest,body.position);if(!step)return;toast(step.record);refresh();if(session.done)showOverlay('기록을 돌려주었습니다','잊혔던 두 사람의 약속이<br>다시 다음 사람에게 이어집니다.','서재 더 둘러보기');}
function showOverlay(title,text,button){paused=true;jumpMotor.pause();weaponSystem?.pauseAudio();input.deactivate();$('overlay-title').textContent=title;$('overlay-text').innerHTML=text;$('start').textContent=button;$('loading').hidden=true;$('restart').hidden=!started;$('overlay').hidden=false;}
function resume(){if(!ready)return;started=true;paused=false;lastFrameTime=performance.now();$('overlay').hidden=true;document.body.classList.add('playing');weaponSystem?.unlock();input.activate();}
function toggleView(){if(!started||paused)return;viewMode=viewMode==='first'?'third':'first';playerView.setMode(viewMode);weaponSystem?.setPerspective(viewMode);canvas.focus();updateInputHint();}
function updateInputHint(){const label=viewMode==='first'?'1인칭':'3인칭',key=id=>preferences.label(id),state=input?.snapshot(),capture=state?.locked?'마우스 잠금':state?.captureChoice==='denied'?'잠금 거절':state?.mode==='free-look'?'자유 시점 (선택)':'시점 대기';$('view-toggle').textContent=`${label} · ${key('view')}`;$('view-toggle').title=`${key('view')}로 1·3인칭 전환`;$('controls').textContent=`${capture}${state?.mode==='free-look'?' · 화면 끝 제한':''} · ${key('view')} ${label} · ${key('sprint')} 달리기 · ${key('jump')} 점프 · Esc 메뉴`;$('pointer-status').textContent=state?.locked?'마우스가 게임에 잠겨 있습니다. Esc로 해제합니다.':state?.lastError?`잠금 거절: ${state.lastError}. 잠금 재시도 또는 자유 시점을 선택할 수 있습니다.`:'입장/계속 클릭에서 잠금을 요청합니다. 자유 시점은 화면 끝 제한이 있습니다.';$('lock-retry').hidden=!started||paused||state?.mode!=='free-look'||!preferences.get().pointerLock;$('free-cursor').hidden=!started||paused||state?.captureChoice!=='denied';$('interact').querySelector('kbd').textContent=key('interact');$('overlay-controls').textContent=`${['forward','left','back','right'].map(key).join(' / ')} 이동 · ${key('sprint')} 달리기 · ${key('jump')} 점프\n마우스 시점 · 좌클릭 발사 · ${key('view')} 1·3인칭\n${key('interact')} 조사 · ${key('tool1')} / ${key('tool2')} 도구 · ${key('reload')} 충전 · Esc 메뉴`;$('weapon-hud').querySelector('p').textContent=`${key('tool1')} / ${key('tool2')} 교체 · ${key('reload')} 충전`;canvas.setAttribute('aria-label',`서재 게임 화면. ${key('forward')} 앞으로, ${key('sprint')} 달리기, ${key('jump')} 점프, ${key('view')} 시점 전환, ${key('interact')} 상호작용`);}
let explainedFallback=false;
const input=createPlayerInput({canvas,preferences,canPlay:()=>started&&!paused,onLook:(dx,dy)=>{const sensitivity=.0026*preferences.get().sensitivity;yaw+=dx*sensitivity;pitch=Math.max(-1.05,Math.min(1.05,pitch+dy*sensitivity));},onFire:()=>weaponSystem?.hold(),onRelease:()=>weaponSystem?.release(),onAction:action=>{if(action==='jump')jumpMotor.request();if(action==='interact')interact();if(action==='view')toggleView();if(action==='tool1')weaponSystem?.select(0);if(action==='tool2')weaponSystem?.select(1);if(action==='reload')weaponSystem?.reload();},onPause:reason=>showOverlay(reason==='blur'?'다시 서재로':'잠시 내려놓은 기록','위치와 기록은 그대로 남아 있습니다.<br>계속하기를 누르면 마우스 시점을 다시 시작합니다.','계속하기'),onMode:mode=>{queueMicrotask(updateInputHint);if(mode==='free-look'&&!explainedFallback){explainedFallback=true;toast('잠금 없는 마우스 시점입니다. 버튼 없이 캔버스 안에서 움직여 둘러보세요. 화면 끝에서는 Esc로 커서를 옮기고 계속하기를 누르세요.');}}});
const keys=input.keys;
$('start').addEventListener('click',resume);$('interact').addEventListener('click',interact);$('view-toggle').addEventListener('click',toggleView);
$('lock-retry').addEventListener('click',()=>input.retry());$('free-cursor').addEventListener('click',()=>input.chooseFree());
$('restart').addEventListener('click',()=>{session.reset();jumpMotor.reset();body.position.set(0,.86,-4.5);yaw=0;pitch=.06;viewMode='first';playerView.setMode(viewMode);weaponSystem?.setPerspective(viewMode);weaponSystem?.reset();refresh();resume();});
$('help').addEventListener('click',()=>showOverlay('서기관의 조작','버튼 없이 마우스로 둘러보고, 좌클릭으로 발사합니다.<br>감도와 키는 설정에서 바꿀 수 있습니다.','계속하기'));
const settingsPanel=createSettingsPanel(preferences,{onOpen(){paused=true;input.deactivate();$('overlay').hidden=true;},onClose(){$('overlay').hidden=false;$('settings-open').focus();}});
$('settings-open').addEventListener('click',()=>settingsPanel.open());preferences.subscribe(()=>{input.clear();updateInputHint();});updateInputHint();
function toggleSound(){const muted=weaponSystem?.toggleMute();for(const id of ['sound','settings-sound']){$(id).textContent=muted?'소리 꺼짐':'소리 켜짐';$(id).setAttribute('aria-pressed',String(Boolean(muted)));}if(!paused)canvas.focus();}
$('sound').addEventListener('click',toggleSound);$('settings-sound').addEventListener('click',toggleSound);
const loadedAssets=[];
async function loadShelf(){const result=await SceneLoader.ImportMeshAsync('','./assets/polyhaven/','bookshelf.gltf',scene);const template=new TransformNode('선반 원본',scene);for(const m of result.meshes){if(!m.parent)m.parent=template;if(m.material){m.material.maxSimultaneousLights=4;m.material.albedoColor=new Color3(.36,.41,.43);m.material.metallic=0;m.material.roughness=.94;m.material.useGLTFLightFalloff=true;if(m.material.albedoTexture)m.material.albedoTexture.anisotropicFilteringLevel=8;}m.receiveShadows=true;}let bounds=template.getHierarchyBoundingVectors(true);const size=bounds.max.subtract(bounds.min);template.scaling.set(2.1/size.x,2.9/size.y,.6/size.z);template.computeWorldMatrix(true);for(const m of result.meshes)m.computeWorldMatrix(true);bounds=template.getHierarchyBoundingVectors(true);template.position.set(-(bounds.min.x+bounds.max.x)/2,-bounds.min.y,-(bounds.min.z+bounds.max.z)/2);
  for(const [x,z] of definition.shelves){const holder=new TransformNode('주변 서가',scene);holder.position.set(x,0,z);holder.rotation.y=x<0?Math.PI/2:-Math.PI/2;const clone=template.clone('PolyHaven 서가',holder);clone.setEnabled(true);const collider=box('서가 충돌',[x,1.45,z],[.6,2.9,2.1],wood,true);collider.isVisible=false;
    for(let row=0;row<3;row++)for(let n=0;n<5;n++){const h=[.063,.654,1.256][row],y=h/2.06344*2.9+.163;const b=book('서가의 기록',[0,0,0],[.14+.02*(n%2),.32,.27],n+row);b.parent=holder;b.position.set((n-2)*.25,y,0);}
  }template.setEnabled(false);loadedAssets.push('Poly Haven wooden_bookshelf_worn');}
engine.runRenderLoop(()=>{const now=performance.now(),raw=(now-lastFrameTime)/1000,dt=Math.min(raw,.25);lastFrameTime=now;let distance=0,actualLocalX=0,actualLocalZ=0;const intent=movementIntent(input,yaw),steps=movementSteps(raw);if(started&&!paused){const old=body.position.clone();for(let i=0;i<steps.count;i++)jumpMotor.step(steps.step,()=>body.position.y,dy=>moveCollider(body,new Vector3(intent.x*steps.step,dy,intent.z*steps.step)),()=>hasGroundContact(scene,body));distance=Math.hypot(body.position.x-old.x,body.position.z-old.z);walkDistance+=Vector3.Distance(old,body.position);if(distance>.00001){const mx=body.position.x-old.x,mz=body.position.z-old.z;actualLocalX=(Math.cos(yaw)*mx-Math.sin(yaw)*mz)/distance;actualLocalZ=(Math.sin(yaw)*mx+Math.cos(yaw)*mz)/distance;}}
const moving=distance>.00001,speed=steps.elapsed?distance/steps.elapsed:0;movementRuntime={speed,running:moving&&intent.running,elapsed:steps.elapsed,substeps:steps.count,walkSpeed:WALK_SPEED,sprintSpeed:SPRINT_SPEED};
playerView.update(dt,{yaw,pitch,moving,distance,speed,airborne:!jumpMotor.snapshot().grounded,localX:actualLocalX,localZ:actualLocalZ,paused:paused||!started,reloading:weaponSystem?.snapshot().state==='reloading'});nearest=null;if(started&&!paused&&session.current&&session.canUse(session.current.target,body.position))nearest=session.current.target;$('interact').hidden=!nearest;$('interact').querySelector('span').textContent=session.current?.action||'';if(now>noticeUntil)$('notice').classList.remove('visible');fragment.rotation.y=Math.sin(now*.0008)*.08;updateRestoration(now);weaponSystem?.tick(dt,moving,paused||!started);if(weaponSystem)playerView.poseArms(weaponSystem.gripTargets());spells.update(started&&!paused?Math.min(raw,.5):0);if(ready)scene.render();});
window.addEventListener('resize',()=>engine.resize());
try{await loadShelf();body.surroundingMeshes=[ground,...collisionBoxes];loadedAssets.push('Poly Haven old_wooden_floor_01');weaponSystem=await createWeapons(scene,camera,{$,toast,thirdPersonAnchor:playerView.toolAnchor,getKeyLabel:action=>preferences.label(action),onShot:shot=>spells.fire(shot),onReset:()=>spells.reset()});
// glTF 9.37 raises every material's light cap to the scene light count on load.
// Reapply a bounded budget after the final import, before the first render.
for(const mat of scene.materials)if(mat.maxSimultaneousLights!==undefined)mat.maxSimultaneousLights=4;
// Static furniture casts real shadows; neither walls nor invisible collision
// boxes occlude the artistic moon fill. Re-render only when restoration changes.
for(const mesh of scene.meshes)if(!mesh.metadata?.playerVisual&&!mesh.metadata?.toolVisual&&!mesh.metadata?.spellEffect&&mesh.renderingGroupId===0&&mesh.isVisible&&mesh.getTotalVertices()>0&&!['마루','서쪽 벽','동쪽 벽','입구 벽','문 왼쪽','문 오른쪽','문 위','문 너머','빛을 삼키는 천장'].includes(mesh.name)){
  shadow.addShadowCaster(mesh,false);
}
shadow.getShadowMap().refreshRate=0;
await spells.ready();await scene.whenReadyAsync();ready=true;$('loading').textContent='서재가 준비되었습니다.';$('start').disabled=false;refresh();}catch(error){console.error(error);$('loading').textContent='불러오기에 실패했습니다. 새로고침해 다시 시도하세요.';$('overlay-text').textContent=error.message;}
Object.defineProperty(window,'__ROOM_DEMO__',{value:Object.freeze({snapshot:()=>({ready,started,paused,viewMode,yaw,pitch,preferences:preferences.get(),jump:jumpMotor.snapshot(),spells:spells.snapshot(),movement:movementRuntime,input:input.snapshot(),player:playerView.snapshot(),phase:session.completed,position:body.position.asArray(),camera:{position:camera.position.asArray(),rotation:camera.rotation.asArray(),fov:camera.fov,viewport:[innerWidth,innerHeight]},lighting:{ambient:ambient.intensity,moon:sun.intensity,desk:deskLight.intensity,portal:portalLight.intensity,portalEnabled:portalLight.isEnabled(),clueEnabled:fragmentLight.isEnabled(),shadowCasters:shadow.getShadowMap().renderList.length,restorationProgress:restorationStart<0?0:Math.min(1,(performance.now()-restorationStart)/3300),seals:archiveMagic.snapshot()},records:session.records,loadedAssets:[...loadedAssets],walkDistance,fps:engine.getFps(),weapon:weaponSystem?.snapshot()||null,meshCount:scene.meshes.length}),audioStream:()=>weaponSystem?.audioStream(),renderStatus:()=>({activeMeshes:scene.getActiveMeshes().length,materials:scene.materials.map(m=>({name:m.name,lights:m.maxSimultaneousLights,internal:m._maxSimultaneousLights,ready:m.isReady()}))})})});
